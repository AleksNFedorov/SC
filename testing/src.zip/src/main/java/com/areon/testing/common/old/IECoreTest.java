package com.areon.testing.common.old;

import com.areon.testing.common.CoreTest;
import org.openqa.selenium.ie.InternetExplorerDriver;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 11/12/13
 * Time: 5:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class IECoreTest extends CoreTest {
/*

    @Override
    protected InternetExplorerDriver createBrowserDriver() throws IOException {
        InternetExplorerDriver driverIE = new InternetExplorerDriver();
        driverIE.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driverIE.manage().window().maximize();
        return driverIE;
    }

    @Override
    protected UsageMethods<InternetExplorerDriver> createUsageMethods(InternetExplorerDriver driver) {
        return new UsageMethods<InternetExplorerDriver>(driver);
    }
*/

}
