package com.areon.testing.mmpp;

import com.areon.testing.common.CoreTest;

/**
 * Created with IntelliJ IDEA.
 * User: Iaremenkoand
 * Date: 24.12.13
 * Time: 10:27
 * To change this template use File | Settings | File Templates.
 */
public class MmppSegmentCoreTest extends CoreTest {
}
