package com.areon.testing.concordion.core.integration;

import com.areon.testing.concordion.core.WebCoreTest;
import com.areon.testing.concordion.core.config.Excludes;
import com.areon.testing.concordion.core.config.Includes;
import com.areon.testing.concordion.core.config.Specification;
import com.areon.testing.concordion.core.config.SpecificationHolder;
import org.concordion.api.Resource;
import org.concordion.api.Result;
import org.concordion.api.RunnerResult;
import org.concordion.internal.runner.DefaultConcordionRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 01.01.14
 * Time: 11:24
 * To change this template use File | Settings | File Templates.
 */
public class ChildTestRunner extends DefaultConcordionRunner {

    private Logger LOG = LoggerFactory.getLogger(ChildTestRunner.class);

    {
        LOG.info("Initialized");
    }

    @Override
    public RunnerResult execute(Resource resource, String href) throws Exception {
        LOG.debug("method invoked [{}], [{}]", href, resource);
        Specification specification = resolveSpecification(href);


        if(specification == null) {
            return new RunnerResult(Result.IGNORED);
        } else {
            GlobalTestContext.getInstance().createNewTestContext(resource, specification);
            LOG.info("Test context created");
            RunnerResult result = super.execute(resource, href);
            LOG.info("Result is ready [{}]", result);
            return result;
        }
    }

    private Specification resolveSpecification(String href) {
        GlobalTestContext.SpecificationContext specificationContext = GlobalTestContext.getInstance().getCurrentTestContext();

        Specification defaultSpecification = new Specification();
        defaultSpecification.setLocation(href);

        Excludes specExcludes = specificationContext.getSpecification().getExcludes();
        Includes specIncludes = specificationContext.getSpecification().getIncludes();

        if(isSpecExcluded(defaultSpecification, specExcludes)) {
            return null;
        } else if(isSpecIncluded(defaultSpecification, specIncludes)) {
            int specIndexInIncludes  = specIncludes.getSpecifications().indexOf(defaultSpecification);
            return specIncludes.getSpecifications().get(specIndexInIncludes);
        } else {
            if(specIncludes == null)
                return defaultSpecification;
            return null;
        }
    }

    public boolean isSpecExcluded(Specification specification, Excludes excludes) {
        return isSpecInSpecHolder(specification, excludes);
    }

    public boolean isSpecIncluded(Specification specification, Includes includes) {
        return isSpecInSpecHolder(specification, includes);
    }

    public boolean isSpecInSpecHolder(Specification specification, SpecificationHolder holder) {
        if(holder != null && holder.getSpecifications().size() > 0) {
            return holder.getSpecifications().contains(specification);
        }
        return false;
    }



    @Override
    protected Class<?> findTestClass(Resource resource, String href) throws ClassNotFoundException {
        return GlobalTestContext.getInstance().getTest().getClazz();
    }
}
