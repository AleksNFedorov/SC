package com.areon.testing.unittest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.io.File;
import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: Iaremenkoand
 * Date: 20.11.13
 * Time: 15:09
 * To change this template use File | Settings | File Templates.
 */
@Test
public class TestingChromeDriver {

    private static final Logger LOG = LoggerFactory.getLogger(TestingChromeDriver.class);

    public void runStartingPage() {
        //File file = new File(Locators.getApplicationProperty(ChromeCoreTest.CHROME_PATH_TO_CHROME_DRIVER_PROPERTY));
        File file = new File("D:/Qaautomated/chromedriver.exe");
        System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);

        final String sUrl = "http://my.kyivstar.net";
        driver.get(sUrl);
        WebElement oSerch = driver.findElement(By.xpath(".//*[@id='login']"));
        oSerch.sendKeys("+380975310412");
        WebElement oInpt = driver.findElement(By.xpath(".//*[@id='password']"));
        oInpt.sendKeys("SelfCare");
        WebElement oBut = driver.findElement(By.xpath(".//*[@id='login_submit']"));
        oBut.click();

        driver.close();
    }

}
