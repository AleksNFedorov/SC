package com.areon.testing.concordion.djuice;

import com.areon.testing.concordion.core.BrowserCoreTest;
import com.areon.testing.concordion.core.WebCoreTest;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 31.12.13
 * Time: 15:35
 * To change this template use File | Settings | File Templates.
 */
public class DjuiceSegmentChromeTest extends WebCoreTest {
}
