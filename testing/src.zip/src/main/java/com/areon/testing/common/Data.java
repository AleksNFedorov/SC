package com.areon.testing.common;

public class Data {

    //public final static String BASE_URL = "https://my.kyivstar.ua";

    public final static String PATH_JENKINS = "/job/Regress_Djuice_Package_2/ws/test-output/";

    public final static  String titleWirelessNumberChrgsUa = "Мій DJUICE - Інші витрати";
    public final static  String titleWirelessNumberChrgsRu = "Мой DJUICE - Прочие затраты";

    public final static  String titleReportsRu = "Мой DJUICE - Отчеты";
    public final static  String titleReportsUa = "Мій DJUICE - Звіти";

    public final static  String titlePersonalProfileRu = "Мой DJUICE - Настройки пользователя";
    public final static  String titlePersonalProfileUa = "Мій DJUICE - Настройки користувача";

    public final static  String titleNotificationsUa = "Мій DJUICE - Повідомлення";
    public final static  String titleNotificationsRu = "Мой DJUICE - Уведомления";

    public final static  String titlePaymentUa = "Мій DJUICE - Історія платежів";
    public final static  String titlePaymentRu = "Мой DJUICE - История платежей";

    public final static  String titleFeaturePageRu = "Мой DJUICE - Управление услугами";
    public final static  String titleFeaturePageUa = "Мій DJUICE - Управління послугами";

    public final static  String titleArchiveOrdersRu = "Мой DJUICE - Управление услугами";
    public final static  String titleArchiveOrdersUa = "Мій DJUICE - Архів заявок";

    public final static  String titleCommunicationUa = "Мій DJUICE - Договір на надання послуг мобільного зв’язку";
    public final static  String titleCommunicationRu = "Мой DJUICE - Договор о предоставлении услуг мобильной связи";

    public final static  String titleAppFormUa = "Мій DJUICE - Аплікаційна форма";
    public final static  String titleAppFormRu = "Мой DJUICE - Аппликационная форма";

    public final static  String titleMoneyTransferUa = "Мій DJUICE - Переказати кошти";
    public final static  String titleMoneyTransferRu = "Мой DJUICE - Перевести средства";

    public final static  String titleMoneyProvidersUa = "Мій DJUICE - Поповнення рахунка";
    public final static  String titleMoneyProvidersRu = "Мой DJUICE - Пополнение счета";

    public final static  String titlesendQuestionUa = "Мій DJUICE - Зворотній зв’язок";
    public final static  String titlesendQuestionRu = "Мой DJUICE - Обратная связь";

    public final static  String titleFaqUa = "Мій DJUICE - Найбільш розповсюджені запитання";
    public final static  String titleFaqRu = "Мой DJUICE - Часто задаваемые вопросы";

    public final static  String titleUserManualUa = "Мій DJUICE - Довідник користувача";
    public final static  String titleUserManualRu = "Мой DJUICE - Руководство пользователя";

    public final static  String titleTermsConditionsUa = "Мій DJUICE - Умови користування";
    public final static  String titleTermsConditionsRu = "Мой DJUICE - Условия использования";

    public final static  String titleSitemapUa = "Мій DJUICE - Карта сайту";
    public final static  String titleSitemapRu = "Мой DJUICE - Карта сайта";

    public final static String linkOverviewPageRU = "Обзор";
    public final static String linkCostsPageRU = "Затраты";
    public final static String linkDetailedUsageRU = "Детализация вызовов";
    public final static String linkUnbilledUsageRU = "Вызовы за текущий месяц";
    public final static String linkWirelessNumberChrgsRU = "Прочие затраты";
    public final static String linkPersonalProfileRU = "Профиль";
    public final static String linkNotificationsRU = "Уведомления";
    public final static String linkAddressBookRU = "Адресная книга";
    public final static String linkPaymentRU = "Платежи";

    public final static String linkReportPageRU = "Отчеты";
    public final static String linkProfilePageRU = "Профиль";
    public final static String linkAddressBookPageRU = "Адресная книга";
    public final static String linkHelpPageRU = "Помощь";
    public final static String linkFeedbackPageRU = "Обратная связь";
    public final static String linkSiteMapPageRU = "Карта сайту";
    public final static String linkFeaturePageRU = "Услуги и акции";
    public final static String linkArchiveOrdersRU = "Архив заявок";

    public final static String detailedUsage = "https://my.djuice.ua/tbmb/b2c/view/detailed_usage.do";

    public final static String saveReportDirectory = "C:/Users/iaremenkoand/Downloads";


    public final static String textOverviewPageRu [] = {
            "Данные пользователя",
            "Состояние",
            "Бонусный баланс",
    };

    public final static String linksOverviewPageRu [][] = {
            {"Обзор", "Overview"},
            {"Затраты", "Expences"},
            {"Профиль", "Profile"},
            {"Платежи", "Payments"},
            {"Услуги и акции", "Services and promotions"},
            {"Контрактное подключение", "B2B subscription"},
            {"Пополнение счета", "Balance re charge"},
            {"Помощь", "Help"},
            {"Карта сайта", "Site map"},
            {"Отправить сообщение", "Send a message"},
    };

    public final static String textOverviewPageUa [] = {
            "Дані користувача",
            "Стан",
            "Бонусний баланс",
    };

    /*
    public final static String linksOverviewPageUa [] = {
            "Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Контрактне підключення",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
            "Надіслати повідомлення",
    };
    */

    public final static String linksOverviewPageUa [][] = {
            {"Огляд", "Overview"},
            {"Витрати", "Statement"},
            {"Профіль", "Profile"},
            {"Платежі", "Payments"},
            {"Послуги та акції", "Services and promotions"},
            {"Контрактне підключення", "B2B subscription"},
            {"Поповнення рахунка", "Balance re charge"},
            {"Допомога", "Help"},
            {"Карта сайту", "Site map"},
            {"Надіслати повідомлення", "Send a message"},
    };

    public final static String LINKS_FTTB_OVERVIEW_PAGE_UA [][] = {
            {"Огляд", "Overview"},
            {"Витрати", "Statement"},
            {"Профіль", "Profile"},
            {"Платежі", "Payments"},
            {"Послуги та акції", "Features and Special offers"},
            {"Поповнення рахунка", "Balance recharge"},
            {"Допомога", "Help"},
            {"Карта сайту", "Site map"},
    };

    public final static String LINKS_FTTB_OVERVIEW_PAGE_RU [][] = {
            {"Обзор", "Overview"},
            {"Затраты", "Statement"},
            {"Профиль", "Profile"},
            {"Платежи", "Payments"},
            {"Услуги и акции", "Features and Special offers"},
            {"Пополнение счета", "Balance recharge"},
            {"Помощь", "Help"},
            {"Карта сайта", "Site map"},
    };

    public final static String LINKS_FTTB_OVERVIEW_PAGE_EN [][] = {
            {"Overview", "Overview"},
            {"Statement", "Statement"},
            {"Profile", "Profile"},
            {"Payments", "Payments"},
            {"Features and Special offers", "Features and Special offers"},
            {"Balance recharge", "Balance recharge"},
            {"Help", "Help"},
            {"Site map", "Site map"},
    };

    public final static String TEXT_FTTB_OVERVIEW_PAGE_RU [] = {
            "Данные пользователя",
            "Состояние лицевого счета",
            "Информация об услуге",
            "Бонусный баланс",
    };

    public final static String TEXT_FTTB_OVERVIEW_PAGE_UA [] = {
            "Дані користувача",
            "Стан особового рахунка",
            "Інформація про послугу",
            "Бонусний баланс",
    };

    public final static String TEXT_FTTB_OVERVIEW_PAGE_EN [] = {
            "User adjustments",
            "Account status",
            "Service information",
            "Bonuses",
    };

    public final static String linksCostPageRu [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Контрактное подключение",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Отправить сообщение",
            "Суммарно",
            "Детализация вызовов",
            "Вызовы за текущий месяц",
            "Прочие затраты",
            "Отчеты",
    };

    public final static String linksCostPageUa [] = {"Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Контрактне підключення",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
            "Надіслати повідомлення",
            "Сумарно",
            "Деталізація викликів",
            "Виклики за поточний місяць",
            "Інші витрати",
            "Звіти",
    };

    public final static String TEXT_DJUICE_COST_SUMMARY_PAGE_UA [] = {
            "Сумарно за період",
            "Дзвінки",
            "Додаткові послуги",
            "Послуги роумінгу",
            "Щомісячні та інші нарахування",
            "Всього, грн.",
            "Отримано платежів",
    };

    public final static String TEXT_DJUICE_COST_SUMMARY_PAGE_RU [] = {
            "Суммарно за период",
            "Звонки",
            "Дополнительные услуги",
            "Услуги роуминга",
            "Ежемесячные и прочие начисления",
            "Итого, грн.",
            "Получено платежей",
    };

    public final static String TEXT_DJUICE_DETAIL_USAGE_PAGE_UA [] = {
            "Деталізація викликів",
            "Деталізація викликів за період",
    };

    public final static String TEXT_DJUICE_DETAIL_USAGE_PAGE_RU [] = {
            "Детализация вызовов",
            "Детализация вызовов за период",
    };

    public final static String TEXT_DJUICE_UNBILLED_USAGE_UA [] = {
            "Виклики за поточний місяць",
    };

    public final static String TEXT_DJUICE_UNBILLED_USAGE_RU [] = {
            "Вызовы за текущий месяц",
    };

    public final static String TEXT_DJUICE_WIRELESS_NUMBER_UA [] = {
            "Прочие затраты",
            "Прочие затраты за",
    };

    public final static String TEXT_DJUICE_WIRELESS_NUMBER_RU [] = {
            "Прочие затраты",
            "Прочие затраты за",
    };

    public final static String TEXT_DJUICE_REPORTS_UA [] = {
            "Звіти",
            "Десять найдорожчих дзвінків за період",
    };

    public final static String TEXT_DJUICE_REPORTS_RU [] = {
            "Отчеты",
            "Десять наиболее дорогих звонков за период",
    };

    public final static String TEXT_DJUICE_PERSONAL_PROFILE_UA [] = {
            "Настройки користувача",
            "Логін:",
            "Ім'я:",
            "Прізвище:",
            "По батькові:",
            "Дата народження:",
            "Стать:",
            "Абонентський номер:",
            "Область:",
            "Район:",
            "Населений пункт:",
            "Вулиця:",
            "Будинок:",
            "Квартира:",
            "Індекс:",
            "Робочий телефон:",
            "Домашній телефон:",
            "Рід занять:",
            "Секретне запитання:",
            "Адреса електронної пошти:",
            "Перевірити електронну пошту:",
            "Видалення облікового запису",
    };

    public final static String TEXT_DJUICE_PERSONAL_PROFILE_RU [] = {
            "Настройки пользователя",
            "Логин:",
            "Имя:",
            "Фамилия:",
            "Отчество:",
            "Дата рождения:",
            "Пол:",
            "Абонентский номер:",
            "Область:",
            "Район:",
            "Населенный пункт:",
            "Улица:",
            "Дом:",
            "Квартира:",
            "Индекс:",
            "Мобильный телефон:",
            "Домашний телефон:",
            "Род занятий:",
            "Секретный вопрос:",
            "Адрес электронной почты:",
            "Проверить электронную почту:",
            "Удаление учетной записи",
    };

    public final static String linksPersonalProfileRu [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Контрактное подключение",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Отправить сообщение",
            "Настройки пользователя",
            "Уведомления",
            "Адресная книга",
    };

    public final static String linksPersonalProfileUa [] = {
            "Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Контрактне підключення",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
            "Надіслати повідомлення",
            "Настройки користувача",
            "Повідомлення",
            "Адресна книга",
    };

    public final static String textPersonalProfileRu [] = {"Настройки пользователя",
            "Логин:",
            "Имя:",
            "Фамилия:",
            "Отчество:",
            "Дата рождения:",
            "Пол:",
            "Абонентский номер:",
            "Область:",
            "Район:",
            "Населенный пункт:",
            "Улица:",
            "Дом:",
            "Квартира:",
            "Индекс:",
            "Мобильный телефон:",
            "Домашний телефон:",
            "Род занятий:",
            "Секретный вопрос:",
            "Адрес электронной почты:",
            "Удаление учетной записи",
    };

    public final static String textNotificationsRu [] = {
            "Для изменения параметров получения уведомлений установите флажок напротив соответствующего типа уведомления. Сохраните настройки, нажав на кнопку \"Сохранить\".",
            "Услуги",
            "Новые услуги и акции",
            "Профиль",
            "Изменение профиля",
            "Электронная почта*",
            "SMS",
            "*Чтобы получать уведомления, укажи и активируй электронный адрес на странице Настройки пользователя",
    };

    public final static String TEXT_DJUICE_NOTIFICATIONS_UA [] = {
            "Для зміни параметрів отримання повідомлень встановіть прапорець напроти відповідного типу повідомлення. Потім натисніть на кнопку \"Зберегти\".",
            "Послуги",
            "Нові послуги та акції",
            "Профіль",
            "Зміна профілю",
            "Електронна пошта*",
            "SMS",
            "*Для того, щоб отримувати повідомлення, вкажіть та активуйте електронну адресу на сторінці Настройки користувача",
    };

    public final static String TEXT_DJUICE_PAYMENT_UA [] = {
            "Історія платежів",
            "Дата",
            "Тип платежу",
            "Додаткова інформація",
            "Сума, грн.",
    };

    public final static String TEXT_DJUICE_PAYMENT_RU [] = {
            "История платежей ",
            "Дата",
            "Тип платежа",
            "Дополнительная информация",
            "Сумма, грн.",
    };

    public final static String TEXT_DJUICE_FEATURE_OVERVIEW_UA [] = {
            "Управління послугами",
            "Дані користувача",
            "Тарифний план",
            "Базові послуги",
            "Голосові послуги",
            "Послуги передачі даних",
            "Інформаційні послуги",

    };

    public final static String TEXT_DJUICE_FEATURE_OVERVIEW_RU [] = {
            "Управление услугами",
            "Данные пользователя",
            "Тарифный план",
            "Базовые услуги",
            "Голосовые услуги",
            "Услуги передачи данных",
            "Информационные услуги",

    };

    public final static String linksPaymentRu [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Контрактное подключение",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Отправить сообщение",
    };

    public final static String linksPaymentUa [] = {
            "Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Контрактне підключення",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
            "Надіслати повідомлення",
    };

    public final static String textPaymentRu [] = {
            "Дата",
            "Тип платежа",
            "Дополнительная информация",
            "Сумма, грн.",
    };

    public final static String linksFeatureRu [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Контрактное подключение",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Отправить сообщение",
            "Управление услугами",
            "Архив заявок",
    };

    public final static String linksFeatureUa [] = {
            "Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Контрактне підключення",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
            "Надіслати повідомлення",
            "Управління послугами",
            "Архів заявок",
    };

    public final static String linksCommunicationRu [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Контрактное подключение",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Отправить сообщение",
            "Договор о предоставлении услуг мобильной связи",
            "Аппликационная форма",
            "Бланки договоров о предоставлении услуг мобильной связи",
            "Договор о предоставлении услуг мобильной связи (Киев)",
            "Договор о предоставлении услуг мобильной связи (Днепропетровск)",
            "Договор о предоставлении услуг мобильной связи (Одесса)",
            "Договор о предоставлении услуг мобильной связи (Харьков)",
            "Договор о предоставлении услуг мобильной связи (Львов)",
            "Договор о предоставлении услуг мобильной связи (Крым)",
            "Пример заполнения",
    };

    public final static String linksCommunicationUa [] = {"Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Контрактне підключення",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
            "Надіслати повідомлення",
            "Договір на надання послуг мобільного зв’язку",
            "Аплікаційна форма",
            "Договір про надання послуг мобільного зв’язку (Київ)",
            "Договір про надання послуг мобільного зв’язку (Дніпропетровськ)",
            "Договір про надання послуг мобільного зв’язку (Одеса)",
            "Договір про надання послуг мобільного зв’язку (Харків)",
            "Договір про надання послуг мобільного зв’язку (Львів)",
            "Договір про надання послуг мобільного зв’язку (Крим)",
            "Приклад заповнення",
    };

    public final static String linksAppFormRu [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Контрактное подключение",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Отправить сообщение",
            "Договор о предоставлении услуг мобильной связи",
            "Аппликационная форма",
            "Бланк аппликационной формы",
            "Пример заполнения",
    };

    public final static String linksAppFormUa [] = {"Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Контрактне підключення",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
            "Надіслати повідомлення",
            "Договір на надання послуг мобільного зв’язку",
            "Аплікаційна форма",
            "Бланк аплікаційної форми",
            "Приклад заповнення",
    };

    public final static String linksMoneyTransferRu [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Контрактное подключение",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Отправить сообщение",
            "Пополнение счета",
            "Перевод средств",
    };

    public final static String linksMoneyTransferUa [] = {
            "Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Контрактне підключення",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
            "Надіслати повідомлення",
            "Переказ коштів",
            "Поповнення рахунка",
    };

    public final static String linkssendQuestionRu [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Контрактное подключение",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Отправить сообщение",
            "Обратная связь",
            "Часто задаваемые вопросы",
            "Руководство пользователя",
            "Условия использования",
    };

    public final static String linkssendQuestionUa [] = {"Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Контрактне підключення",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
            "Надіслати повідомлення",
            "Зворотній зв’язок",
            "Найбільш розповсюджені запитання",
            "Довідник користувача",
            "Умови користування",
    };

    public final static String linksFaqRu [] = {
            "1. Как защищена информация в cистеме «Мой DJUICE»?",
            "2. Могу ли я войти в систему «Мой DJUICE» с любого компьютера?",
            "3. Какой браузер я могу использовать для входа в систему «Мой DJUICE»?",
            "4. Сколько стоит пользование системой «Мой DJUICE»?",
            "5. Почему при просмотре детализации вызовов не отображаются имена из адресной книги?",
            "6. Почему я не вижу детализацию вызовов за предыдущий месяц?",
            "7. Почему я не вижу суммарные затраты за предыдущий месяц?",
            "8. Почему я не вижу отчеты за предыдущий месяц?",
            "9. Почему у меня суммарные затраты одни, а детализированные другие?",
            "10. Почему при нажатии на ссылку <название раздела> произошел переход на страницу <Вход в систему>?",
            "11. Почему в системе не отображены мои затраты на услуги мобильной связи с даты моего подключения к сети «Киевстар»?",
    };

    public final static String linksFaqUa [] = {"1. Як захищена інформація у системі «Мій DJUICE»?",
            "2. Чи можу я увійти до системи «Мій DJUICE» з будь-якого комп’ютера?",
            "3. Який браузер я можу використовувати для входу до системи «Мій DJUICE»?",
            "4. Скільки коштує користування системою «Мій DJUICE»?",
            "5. Чому під час перегляду деталізації викликів не відображаються імена з адресної книги?",
            "6. Чому я не бачу деталізацію викликів за попередній місяць?",
            "7. Чому я не бачу сумарні витрати за попередній місяць?",
            "8. Чому я не бачу звіти за попередній місяць?",
            "9. Чому у мене сумарні витрати одні, а деталізовані інші?",
            "10. Чому, клікнувши на посилання <назва розділу> я перейшов на сторінку <Вхід до системи>?",
            "11. Чому у системі не відображені мої витрати на послуги мобільного зв’язку з дати мого підключення до мережі «Київстар»?",
    };

    public final static String linksSitemapRu [] = {"Обзор",
            "Затраты",
            "Суммарно",
            "Детализация вызовов",
            "Вызовы за текущий месяц",
            "Прочие затраты",
            "Отчеты",
            "Профиль",
            "Настройки пользователя",
            "Уведомления",
            "Адресная книга",
            "Платежи",
            "Услуги и акции",
            "Управление услугами",
            "Архив заявок",
            "Контрактное подключение",
            "Договор о предоставлении услуг мобильной связи",
            "Аппликационная форма",
            "Пополнение счета",
            "Перевод средств",
            "Пополнение счета",
            "Помощь",
            "Обратная связь",
            "FAQ",
            "Руководство пользователя",
            "Условия использования",
            "Карта сайта",
    };

    public final static String linksSitemapUa [] = {"Огляд",
            "Витрати",
            "Сумарно",
            "Деталізація викликів",
            "Виклики за поточний місяць",
            "Інші витрати",
            "Звіти",
            "Профіль",
            "Настройки користувача",
            "Повідомлення",
            "Адресна книга",
            "Платежі",
            "Послуги та акції",
            "Управління послугами",
            "Архів заявок",
            "Контрактне підключення",
            "Договір на надання послуг мобільного зв’язку",
            "Аплікаційна форма",
            "Поповнення рахунка",
            "Переказ коштів",
            "Поповнення рахунка",
            "Допомога",
            "Зворотній зв’язок",
            "FAQ",
            "Довідник користувача",
            "Умови користування",
            "Карта сайту",
    };
}

