package com.areon.testing.concordion.core;

import com.areon.testing.common.Locators;
import com.areon.testing.common.context.BrowserDriverService;
import com.areon.testing.concordion.core.config.Test;
import com.areon.testing.concordion.core.integration.CoreJUnitRunner;
import com.areon.testing.concordion.core.integration.GlobalTestContext;
import com.areon.testing.concordion.core.runner.SuiteConfiguration;
import org.concordion.api.FailFast;
import org.concordion.api.extension.Extensions;
import org.concordion.ext.ScreenshotExtension;
import org.concordion.internal.util.Check;
import org.junit.After;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 31.12.13
 * Time: 15:29
 * To change this template use File | Settings | File Templates.
 */
@RunWith(CoreJUnitRunner.class)
@FailFast(onExceptionType = {WebDriverException.class})
@Extensions(ScreenshotExtension.class)
public class BrowserCoreTest {

    private Logger LOG = LoggerFactory.getLogger(BrowserCoreTest.class);


    public boolean openBrowser(String browserCapture) throws Exception {
        LOG.debug("method invoked [{}]", browserCapture);
        Check.notNull(browserCapture, "Browser can' t be null");
        Locators.Browser browser = Locators.Browser.valueOf(browserCapture);
        RemoteWebDriver driver = new BrowserDriverService().createDriver(browser);

        Test test = SuiteConfiguration.getInstance().getTestByClass(getClass());

        GlobalTestContext.createGlobalContext(driver, test);
        LOG.debug("method invoked");
        return true;
    }

    @After
    public void onTestEnd() {
        GlobalTestContext.getInstance().destroyCurrentTestContext();
    }


    public boolean close() {
        getCurrentTestDriver().close();
        return true;
    }

    public String getBrowserState() {
        try {
            getCurrentTestDriver().getTitle();
            return Locators.BrowserWindowState.Open.toString();
        } catch (SessionNotFoundException e) {
            return Locators.BrowserWindowState.Closed.toString();
        }
    }

    protected RemoteWebDriver getCurrentTestDriver() {
        LOG.debug("method invoked");
        return GlobalTestContext.getInstance().getDriver();
    }

}
