package com.areon.testing.common;

import com.areon.testing.common.context.TestContextService;
import com.areon.testing.common.context.TestMethodContext;
import com.areon.testing.common.old.UsageMethods;
import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.util.Locale;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 11/6/13
 * Time: 4:52 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class CoreTest {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    private final ApplicationContext context;

    protected UsageMethods method;

    private TestContextService testContextService;

    public CoreTest() {
        context = new ClassPathXmlApplicationContext("application.xml");
    }

    @Parameters({"browser", "segment"})
    @BeforeTest(groups = {"internetExplorer", "chrome", "fireFox"})
    public void initTest(String browser, String segment) throws Exception {
        LOG.info("Test instance initalization start");
        testContextService = createTestContextService(browser, segment);
        method = createUsageMethods();
        LOG.info("Test successfully initialized");
    }

    @BeforeMethod(groups = {"internetExplorer", "chrome", "fireFox"})
    public void initMethod(Method method) {
        LOG.debug("initMethod invoked [{}]", method.getName());
        testContextService.createMethodContext(method);
        LOG.debug("initMethodFinished");
    }

    protected void verifyTimeout(String timeOutMessageKey, Locale locale) {
        LOG.debug("method invoked with locale [{}] and time out message key [{}]", locale, timeOutMessageKey);

        if (method.isElementPresentByText(getMessage(timeOutMessageKey, locale))) {
            method.onFail("Timeout", "User session broken out due to timeout exception");
            org.junit.Assert.fail("Timeout exception");
        } else {
            LOG.info("No timout message found");
        }
        LOG.debug("method finished");
    }

    protected void verifyDataDownloadReport(String downloadMessage, Locale locale) {
        LOG.debug("method invoked with locale [{}] and data on download page [{}]", locale, downloadMessage);

        if (method.isElementPresentByText(getMessage(downloadMessage, locale))) {
            method.onFail("No data to display", "User session broken out to void page");
            org.junit.Assert.fail("Void page - No data to display");

        } else {
            LOG.info("No page with void data");
        }
        LOG.debug("method finished");
    }

    protected void downloadReport(Locators.ReportType report, Locale currentLocale) {
        downloadReport(report, currentLocale, true);
    }

    protected void downloadReport(Locators.ReportType report, Locale currentLocale, boolean needClickLink) {
        LOG.debug("method invoked with [{}], [{}]", report, currentLocale);

        try {
            if (needClickLink) {
                String[] saveToFileLink = getCompositeMessage(Locators.FTTB_REPORT_SAVE_TO_FILE_LINK, currentLocale);
                LOG.info("Trying to find and click on save to file link");
                method.clickOnElementBy(By.linkText(saveToFileLink[0]), saveToFileLink[1]);
            }

            String[] downloadLink = getCompositeMessage(Locators.FTTB_REPORT_DOWNLOAD_LINK, currentLocale);

            LOG.info("Trying to download report");
            method.downloadReport(report.name(), downloadLink[0], downloadLink[1]);
        } catch (Exception ex) {
            String exceptionReason = "Exception during report downloading [" + report + "]";
            LOG.error(exceptionReason, ex.getMessage());
            method.onFail(ex.getMessage(), exceptionReason);
        } finally {
            LOG.debug("method finished");
        }
    }


    public String[][] getCompositeMessages(String key, Locale locale) {
        LOG.debug("Get complex message invoked, key [{}], locale [{}]", key, locale);
        String origComplexMessage = getMessage(key, locale);
        String[] messages = origComplexMessage.split("###");
        String[][] completeMessages = new String[messages.length][];
        for (int i = 0; i < completeMessages.length; ++i) {
            completeMessages[i] = splitAndTrim(messages[i]);
        }
        LOG.debug("method successfully finished ");
        return completeMessages;
    }

    public String[] getCompositeMessage(String key, Locale locale) {
        LOG.debug("Get complex message invoked, key [{}], locale [{}]", key, locale);
        String compositeMessage = getMessage(key, locale);
        return splitAndTrim(compositeMessage);
    }

    private String[] splitAndTrim(String source) {
        String[] messageWithModifier = source.split("\\|");
        for (int i = 0; i < messageWithModifier.length; ++i) {
            messageWithModifier[i] = messageWithModifier[i].trim();
        }
        return messageWithModifier;
    }


    public String getMessage(String key, Locale locale) {
        LOG.debug("method invoked, key [{}], locale [{}]", key, locale);
        return context.getMessage(key, null, locale);
    }

    public TestMethodContext getTestMethodContext() {
        LOG.debug("method invoked");
        return testContextService.getCurrentTestMethodContext();
    }

    public RemoteWebDriver getWebDriver() {
        LOG.debug("method invoked");
        return testContextService.getDriver();
    }

    protected void checkTestFailed() {
        LOG.debug("method invoked");
        TestMethodContext currentTestMethodContext = testContextService.getCurrentTestMethodContext();
        LOG.debug("Method fail [{}], reason is [{}]", currentTestMethodContext.isMethodFailed(), currentTestMethodContext.getMethodFailReason());
        Assert.assertTrue(getTestMethodContext().getMethodFailReason(), Boolean.FALSE.equals(getTestMethodContext().isMethodFailed()));
        LOG.debug("method finished");
    }

    @AfterMethod(groups = {"internetExplorer", "chrome", "fireFox"})
    public void onMethodFinish() {
        LOG.debug("method invoked");
        testContextService.destroyMethodContext();
        LOG.debug("method finished");
    }

    @AfterTest(groups = {"internetExplorer", "chrome", "fireFox"})
    public void tearDown() {
        LOG.info("tearing down class");
        testContextService.destroyTest();
        LOG.info("Driver quited successfully");
    }


    protected TestContextService createTestContextService(String browser, String segment) throws Exception {
        return new TestContextService(segment, browser);
    }

    protected UsageMethods createUsageMethods() {
        return new ContentVerificationHelper(testContextService);
    }
}
