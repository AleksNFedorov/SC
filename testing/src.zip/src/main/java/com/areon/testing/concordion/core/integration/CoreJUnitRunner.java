package com.areon.testing.concordion.core.integration;

import org.concordion.api.ResultSummary;
import org.concordion.api.SpecificationLocator;
import org.concordion.integration.junit4.ConcordionRunner;
import org.concordion.internal.*;
import org.junit.runner.Description;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;
import org.junit.runners.model.Statement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 01.01.14
 * Time: 13:45
 * To change this template use File | Settings | File Templates.
 */
public class CoreJUnitRunner extends ConcordionRunner {

    private static final Logger LOG = LoggerFactory.getLogger(CoreJUnitRunner.class);


    private final Description fixtureDescription;
    private ResultSummary result;

    public CoreJUnitRunner(Class<?> fixtureClass) throws InitializationError {
        super(fixtureClass);
        LOG.debug("method invoked");
        String testDescription = ("[Concordion Specification for '" + fixtureClass.getSimpleName()).replaceAll("Test$", "']"); // Based on suggestion by Danny Guerrier
        fixtureDescription = Description.createTestDescription(fixtureClass, testDescription);

    }

    @Override
    protected void runChild(FrameworkMethod method, RunNotifier notifier) {
        LOG.debug("method invoked");
        super.runChild(method, notifier);    //To change body of overridden methods use File | Settings | File Templates.
        if (result != null && result.getIgnoredCount() > 0) {
            notifier.fireTestIgnored(fixtureDescription);
        }
    }

    @Override
    protected Statement specExecStatement(final Object fixture) {
        LOG.debug("method invoked");
        return new Statement() {
            public void evaluate() throws Throwable {
                FixtureRunner runner = new FixtureRunner();
                runner.setSpecificationLocator(resolveLocator());
                result = runner.run(fixture);
            }
        };
    }

    protected SpecificationLocator resolveLocator() {
        LOG.debug("method invoked");
        if(GlobalTestContext.getInstance() == null
                || GlobalTestContext.getInstance().getCurrentTestContext().isTopLevelTest()) {
            LOG.info("current test is a top level test, default locator will be used");
            return new ClassNameBasedSpecificationLocator();
        }
        LOG.info("current test is not top level, context locator will be used");
        return new TestContextSpecificationLocator();

    }

}
