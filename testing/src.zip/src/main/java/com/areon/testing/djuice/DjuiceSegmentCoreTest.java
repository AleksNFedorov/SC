package com.areon.testing.djuice;

import com.areon.testing.common.CoreTest;
import com.areon.testing.common.Data;
import com.areon.testing.common.Locators;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 12/2/13
 * Time: 2:47 PM
 * To change this template use File | Settings | File Templates.
 */
public class DjuiceSegmentCoreTest extends CoreTest {

    private static Logger LOG = LoggerFactory.getLogger(DjuiceSegmentCoreTest.class);

    @BeforeTest(groups = {"internetExplorer", "chrome", "fireFox"})
    public void initDriver() {
        LOG.debug("initDriver start");

        RemoteWebDriver driver = getWebDriver();

        try {
            driver.get(Locators.getApplicationProperty(Locators.GO_TO_BASE_URL_DJUICE));

            //login on system
            WebElement searchField = driver.findElement(By.xpath(Locators.loginFormXpath));
            searchField.clear();
            searchField.sendKeys(Locators.getApplicationProperty(Locators.DJUICE_LOGIN));
            WebElement searchField2 = driver.findElement(By.name(Locators.passwordFormName));
            searchField2.clear();
            searchField2.sendKeys(Locators.getApplicationProperty(Locators.DJUICE_PASSWORD));
            WebElement searchButton = driver.findElement(By.name(Locators.submitButtonName));
            searchButton.click();

            //check on correct data login and password
            if (method.isElementPresentByXpath(".//*[@id='errorsTable']")) {
                LOG.info("Error on Login Page: " + driver.findElement(By.xpath(".//*[@id='errorsTable']")).getText());
            } else {
            }
        } catch (Exception e) {
            LOG.error("Exception during driver inialization", e);
        }

    }


    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void testCaseOnOverviewPage() {


        overviewPageTest(Locators.LOCALE_RU);
        overviewPageTest(Locators.LOCALE_UA);

        checkTestFailed();
    }

    private void overviewPageTest(Locale locale) {


        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.verifyTitle(getCompositeMessage(Locators.TITLE_OVERVIEW_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_PAGE_CORE_ELEMENTS, locale));

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    //Test #2 - check data on
    public void k() {

        costPageSummaryTestWithLocale(Locators.LOCALE_RU);
        costPageSummaryTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }

    private void costPageSummaryTestWithLocale(Locale locale) {


        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.clickOnElementBy(By.xpath("./*//*[@id='2']/a"), "DJUICE page summary element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_COST_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_COST_PAGE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_COST_SUMMARY_PAGE_ELEMENTS, locale));

        downloadReports(locale);

    }


    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void detailedUsagePageTest(){
         detailedUsagePageTestWithLocale(Locators.LOCALE_RU);
         detailedUsagePageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void detailedUsagePageTestWithLocale(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='2']/a"), "Djuice expences");
        method.clickOnElementBy(By.xpath("./*//*[@id='2_2']/a"), "Djuice usage details");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_DETAIL_USAGE_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_COST_PAGE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_DETAIL_USAGE_PAGE_ELEMENTS, locale));

        downloadReports(locale);

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void unBilledUsagePageTest(){
        unBilledUsagePageTestWithLocale(Locators.LOCALE_RU);
        unBilledUsagePageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void unBilledUsagePageTestWithLocale(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='2']/a"), "Djuice expences page");
        method.clickOnElementBy(By.xpath("./*//*[@id='2_3']/a"), "Djuice current period");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_UNBILL_USAGE_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_COST_PAGE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_UNBILL_USAGE_PAGE_ELEMENTS, locale));

        downloadReports(locale);

    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void wirelessNumberPageTest(){
        wirelessNumberPageTestWithLocale(Locators.LOCALE_RU);
        wirelessNumberPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void wirelessNumberPageTestWithLocale(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        //TO DO have got to know what this 2 lines do
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='2']/a"), "DJUICE expenses page");
        method.clickOnElementBy(By.xpath("./*//*[@id='2_4']/a"), "DJUICE other expenses");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_WIRELESS_NUMBER_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_COST_PAGE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_WIRELESS_NUMBER_PAGE_ELEMENTS, locale));

        downloadReports(locale);

    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void reportsPageTest(){
        reportsPageTestWithLocale(Locators.LOCALE_RU);
        reportsPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void reportsPageTestWithLocale(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='2']/a"), "DJUICE expenses page");
        method.clickOnElementBy(By.xpath("./*//*[@id='2_5']/a"), "Djuice reports");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_REPORTS_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_COST_PAGE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_REPORTS_PAGE_ELEMENTS, locale));

        downloadReports(locale);

    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void personalProfilePageTest() {
        personalProfilePageTestWithLocale(Locators.LOCALE_RU);
        personalProfilePageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }

    private void personalProfilePageTestWithLocale(Locale locale){

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='3']/a"), "DJUICE profile page");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_PERSONAL_PROFILE_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_PERSONAL_PROFILE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_PERSONAL_PROFILE_PAGE_ELEMENTS, locale));

        String[] editButtonTag = getCompositeMessage(Locators.GENERAL_EDIT_BUTTON, locale);
        String[] saveButtonTag = getCompositeMessage(Locators.GENERAL_SAVE_BUTTON, locale);

        method.clickOnElementBy(By.xpath(editButtonTag[0]), editButtonTag[1]);//to do edit button modifyer

            method.fillTextField("./*//*[@id='firstName_field']", "TestName");
            method.fillTextField("./*//*[@id='lastName_field']", "TestSubname");
            method.fillTextField("./*//*[@id='email_field']", "test@test.test");


            method.clickOnElementBy(By.xpath(saveButtonTag[0]), saveButtonTag[1]); //to do save button modifyer

                if (method.isElementPresentByXpath(Locators.greenMessage)) {
                    LOG.info("Success message ");
                } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                    LOG.info("ErrorMessage ");
                } else {
                    LOG.info("No message");
                }
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void notificationsPageTest() {
        notificationsPageTestWithLocale(Locators.LOCALE_RU);
        notificationsPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void notificationsPageTestWithLocale(Locale locale){

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));

        method.clickOnElementBy(By.xpath("./*//*[@id='3']/a"), "DJUICE profile page");
        method.clickOnElementBy(By.xpath("./*//*[@id='3_3']/a"), "DJUICE notifications page");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_NOTIFICATIONS_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_PERSONAL_PROFILE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_NOTIFICATIONS_PAGE_ELEMENTS, locale));

        String[] saveButtonTag = getCompositeMessage(Locators.GENERAL_SAVE_BUTTON, locale);

        method.clickOnElementBy(By.xpath(saveButtonTag[0]), saveButtonTag[1]);
        method.verifySizeElements("//input[@type='checkbox']", 6, "checkbox");
        method.verifyClickableElements("//input[@type='checkbox']");
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void personalAddressBookPageTest() {
        personalAddressBookPageTestWithLocale(Locators.LOCALE_RU);
        personalAddressBookPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void personalAddressBookPageTestWithLocale (Locale locale){

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='3']/a"), "DJUICE profile page");
        method.clickOnElementBy(By.xpath("./*//*[@id='3_4']/a"), "DJUICE personal address book");

        String dateFormat = "MM.dd_h.mm.ss";
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat SDF = new SimpleDateFormat(dateFormat);
        String randomNumber = SDF.format(cal.getTime());

        method.fillTextField("./*//*[@name='phoneNumber']", randomNumber);
        method.fillTextField("./*//*[@name='alias']", randomNumber);
        method.fillTextField("./*//*[@name='name']", randomNumber);

        String[] saveButtonTag = getCompositeMessage(Locators.GENERAL_SAVE_BUTTON, locale);

        method.clickOnElementBy(By.xpath(saveButtonTag[0]), saveButtonTag[1]);
        if (method.isElementPresentByXpath(Locators.greenMessage)) {
            LOG.info("Success message ");
        } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
            LOG.info("ErrorMessage ");
        } else {
            LOG.info("No message");
        }
        //to make sure we stay at previous page
        method.clickOnElementBy(By.xpath("./*//*[@id='3_4']/a"), "DJUICE personal address book");
        method.verifyClickableElements("//input[@type='checkbox']");
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void paymentPageTest(){
        paymentPageTestWithLocale(Locators.LOCALE_RU);
        paymentPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void paymentPageTestWithLocale(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='4']/a"), "DJUICE payment page");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_PAYMENT_ACTIVITY_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_PAYMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_PAYMENT_PAGE_ELEMENTS, locale));
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void featureOverviewPageTest(){
        featureOverviewPageTestWithLocale(Locators.LOCALE_RU);
        featureOverviewPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void featureOverviewPageTestWithLocale(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='5']/a"), "DJUICE features");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_FEATURE_OVERVIEW_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_FEATURE_OVERVIEW, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.DJUICE_FEATURE_OVERVIEW_PAGE_ELEMENTS, locale));
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void archieveOrdersPageTest(){
        archieveOrdersPageTestWithLocale(Locators.LOCALE_RU);
        archieveOrdersPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void archieveOrdersPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='5']/a"), "DJUICE Services and features");
        method.clickOnElementBy(By.xpath("./*//*[@id='5_3']/a"), "DJUICE archieve orders page");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_ARCHIVE_ORDERS_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_FEATURE_OVERVIEW, locale));
        method.changeFeature();
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void mobileComunicationPageTest(){
        mobileComunicationPageTestWithLocale(Locators.LOCALE_RU);
        mobileComunicationPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void mobileComunicationPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='9']/a"), "DJUICE mobile comunication page");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_COMMUNICATION_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_COMMUNICATION, locale));
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
     public void appFormPageTest(){
        appFormPageTestWithLocale(Locators.LOCALE_RU);
        appFormPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void appFormPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='9']/a"), "DJUICE PostPaid service");
        method.clickOnElementBy(By.xpath("./*//*[@id='9_2']/a"), "DJUICE application form");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_APPLICATION_FORM_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_APPLICATION_FORM, locale));
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void moneyTransferPageTest(){
        moneyTransferPageTestWithLocale(Locators.LOCALE_RU);
        moneyTransferPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void moneyTransferPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='6']/a"), "DJUICE money transfer");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_MONEY_TRANSFER_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_MONEY_TRANSFER, locale));

        method.fillTextField("./*//*[@id='phone']", "971202020");
        method.fillTextField("./*//*[@id='transferAmount']", "1");

        for (int i = 0; i < 3; i++) {
            method.clickOnElementBy(By.xpath(Locators.submitButton),"DJUICE money transfer page submit button");
            if (method.isElementPresentByXpath(Locators.greenMessage)) {
                LOG.info("Success message ");
                break;
            } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                LOG.info("ErrorMessage ");
                break;
            } else {
                LOG.info("Nothing");
                break;
            }
        }
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void providersPageTest(){
        providersPageTestWithLocale(Locators.LOCALE_RU);
        providersPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void providersPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));

        method.clickOnElementBy(By.xpath("./*//*[@id='6']/a"), "DJUICE money transfer");
        method.clickOnElementBy(By.xpath("./*//*[@id='6_2']/a"), "DJUICE providers page");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_MONEY_PROVIDERS_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_MONEY_TRANSFER, locale));

        method.verifyElementValue("./*//*[@href='/tbmb/balance_recharge.do?provider=0']", "Портмоне.сом", "Provider |");
        method.verifyElementValue("./*//*[@href='/tbmb/balance_recharge.do?provider=1']", "EasyPay", "Provider |");
        method.verifyElementValue("./*//*[@href='/tbmb/balance_recharge.do?provider=2']", "Приватбанк", "Provider |");
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void sendQuestionPageTest(){
        sendQuestionPageTestWithLocale(Locators.LOCALE_RU);
        sendQuestionPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void sendQuestionPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='7']/a"), "DJUICE send question");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_SEND_QUESTION_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_SEND_QUESTION, locale));
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void faqPageTest(){
        faqPageTestWithLocale(Locators.LOCALE_RU);
        faqPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void faqPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='7']/a"), "DJUICE send question");
        method.clickOnElementBy(By.xpath("./*//*[@id='7_2']/a"), "DJUICE faq");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_FAQ_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_SEND_QUESTION, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_FAQ, locale));
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
     public void userManualPageTest(){
        userManualPageTestWithLocale(Locators.LOCALE_RU);
        userManualPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void userManualPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='7']/a"), "DJUICE send question");
        method.clickOnElementBy(By.xpath("./*//*[@id='7_4']/a"), "DJUICE user manual");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_USER_MANUAL_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_SEND_QUESTION, locale));
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void termsConditionsPageTest(){
        termsConditionsPageTestWithLocale(Locators.LOCALE_RU);
        termsConditionsPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void termsConditionsPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='7']/a"), "DJUICE send question");
        method.clickOnElementBy(By.xpath("./*//*[@id='7_5']/a"), "DJUICE terms conditions");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_TERMS_CONDITIONS_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_SEND_QUESTION, locale));
    }
    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA"})
    public void siteMapPageTest(){
        siteMapPageTestWithLocale(Locators.LOCALE_RU);
        siteMapPageTestWithLocale(Locators.LOCALE_UA);

        checkTestFailed();
    }
    private void siteMapPageTestWithLocale(Locale locale){
        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);
        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_DJUICE_KEY, locale));
        method.clickOnElementBy(By.xpath("./*//*[@id='8']/a"), "DJUICE site map");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_SITEMAP_DJUICE, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.LINKS_SITE_MAP, locale));
    }

    private void downloadReports(Locale locale) {
        String[] saveToFileLink = getCompositeMessage(Locators.REPORT_SAVE_TO_FILE_LINK, locale);
        String[] downloadLink = getCompositeMessage(Locators.REPORT_DOWNLOAD_LINK, locale);

        method.clickOnElementBy(By.linkText(saveToFileLink[0]),saveToFileLink[1]);
        method.downloadReport("CSV", downloadLink[0], downloadLink[1]);


        method.clickOnElementBy(By.linkText(saveToFileLink[0]),saveToFileLink[1]);
        method.downloadReport("XML", downloadLink[0], downloadLink[1]);
    }

}
