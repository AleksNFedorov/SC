package com.areon.testing.common.old;

import com.areon.testing.common.CoreTest;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 11/12/13
 * Time: 5:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChromeCoreTest extends CoreTest {
/*

    public static final String PATH_TO_CHROME_DRIVER_PROPERTY = "path.to.chromeDriver";

    @Override
    protected ChromeDriver createBrowserDriver() throws IOException {
        String systemSpecificChromeDriver = Locators.getApplicationProperty(PATH_TO_CHROME_DRIVER_PROPERTY);

        System.setProperty("webdriver.chrome.driver", systemSpecificChromeDriver);
        ChromeDriverService defaultService = ChromeDriverService.createDefaultService();
        defaultService.start();
        ChromeDriver driver = new ChromeDriver(defaultService);

        driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);

        return driver;
    }

    @Override
    protected UsageMethods<ChromeDriver> createUsageMethods(ChromeDriver driver) {
        return new UsageMethods<ChromeDriver>(driver);
    }
*/

}
