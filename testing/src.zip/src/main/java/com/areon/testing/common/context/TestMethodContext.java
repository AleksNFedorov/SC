package com.areon.testing.common.context;

import com.areon.testing.common.Locators;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.lang.reflect.Method;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 12/3/13
 * Time: 9:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class TestMethodContext {

    private final Method testMethod;

    private String methodFailReason = "";

    private boolean methodFailed;

    private final Locators.Browser browser;

    private final Locators.Segment segment;


    public TestMethodContext(Method testMethod, Locators.Browser browser, Locators.Segment segment) {
        this.testMethod = testMethod;
        this.browser = browser;
        this.segment = segment;
    }

    public Locators.Browser getBrowser() {
        return browser;
    }

    public Locators.Segment getSegment() {
        return segment;
    }

    public Method getTestMethod() {
        return testMethod;
    }

    public boolean isMethodFailed() {
        return methodFailed;
    }

    public String getMethodFailReason() {
        return methodFailReason;
    }

    public void setMethodFailed(String reason) {
        this.methodFailed = true;
        methodFailReason += "["+reason+"]";
    }

    @Override
    public String toString() {
        return "TestMethodContext{" +
                "testMethod=" + testMethod +
                ", methodFailReason='" + methodFailReason + '\'' +
                ", methodFailed=" + methodFailed +
                ", browser=" + browser +
                ", segment=" + segment +
                '}';
    }
}
