package com.areon.testing.concordion.core.config;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 03.01.14
 * Time: 13:36
 * To change this template use File | Settings | File Templates.
 */
public interface SpecificationHolder {

    public List<Specification> getSpecifications();


}
