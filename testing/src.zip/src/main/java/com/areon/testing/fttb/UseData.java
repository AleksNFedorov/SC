package com.areon.testing.fttb;

public class UseData {
    private UseData(){
        throw new AssertionError("Call is denied");
    }

    //general data >>
    public final static String BASE_URL = "https://my.kyivstar.ua";
    public final static String BASE_LOGIN = "4794655"; //продуктивные номера ДИ 4794655
    public final static String BASE_PASSWD = "SelfCare!@3";

    public final static String PATH_JENKINS = "/job/Regress_FTTB_Package_2/ws/test-output/"; //рефакторинг данного пути, т.к. он реально поменялся
    //general data <<


    //data for overview page >>
    public final static String TITLE_OVERVIEW_UA = "Мій Київстар - Огляд";
    public final static String TITLE_OVERVIEW_RU = "Мой Киевстар - Обзор";
    public final static String TITLE_OVERVIEW_EN = "My Kyivstar - Overview";

    public final static String LINKS_OVERVIEW_PAGE_UA[] = {
            "Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту",
    };

    public final static String linksOverviewPageRu [] = {"Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
    };

    public final static String linksOverviewPageEn [] = {"Overview",
            "Statement",
            "Profile",
            "Payments",
            "Features and Special offers",
            "Balance recharge",
            "Help",
            "Site map",
    };

    public final static String textOverviewPageUa [] = {"Дані користувача",
            "Стан особового рахунка",
            "Інформація про послугу",
            "Бонусний баланс",
    };

    public final static String textOverviewPageRu [] = {"Данные пользователя",
            "Состояние лицевого счета",
            "Информация об услуге",
            "Бонусный баланс",
    };

    public final static String textOverviewPageEn [] = {"User adjustments",
            "Account status",
            "Service information",
            "Bonuses",
    };

    //data for overview page <<

    //data for cost page >>
    public final static String titleCostAgreementUA = "Мій Київстар - По номеру договору";
    public final static String titleCostAgreementRU = "Мой Киевстар - По номеру договора";
    public final static String titleCostAgreementEN = "My Kyivstar - Agreement";

    public final static String titleCostUnbilledUA = "Мій Київстар - Трафік за поточний місяць";
    public final static String titleCostUnbilledRU = "Мой Киевстар - Трафик за текущий месяц";
    public final static String titleCostUnbilledEN = "My Kyivstar - Unbilled";

    public final static String titleCostReportUA = "Витрати - Звіти";
    public final static String titleCostReportRU = "Мой Киевстар - Отчеты";
    public final static String titleCostReportEN = "Statement - Reports";

    public final static String linksCostAgreementRU [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Пополнение счета",
            "Помощь",
            "Карта сайта"
    };

    public final static String linksCostAgreementUA [] = {
            "Огляд",
            "Витрати",
            "Профіль",
            "Платежі",
            "Послуги та акції",
            "Поповнення рахунка",
            "Допомога",
            "Карта сайту"
    };

    public final static String linksCostAgreementEN [] = {
            "Overview",
            "Statement",
            "Profile",
            "Payments",
            "Features and Special offers",
            "Balance recharge",
            "Help",
            "Site map"
    };

    public final static String textCostAgreementRUPhoneSum [] = {
            "По номеру договора",
            "Трафик за текущий месяц",
            "Отчеты",
            "Суммарно",
            "Детализация трафика",
            "Детализация начислений",
            "Всего, без скидки",
            "Всего, со скидкой",
            "Тарифы указаны в гривнах с учетом НДС."
    };

    public final static String textCostAgreementUAPhoneSum [] = {
            "По номеру договору",
            "Сумарно",
            "Деталізація трафіку",
            "Деталізація нарахувань",
            "Всього, без знижки",
            "Всього, зі знижкою",
            "Тарифи наведено у гривнях з урахуванням ПДВ."
    };

    public final static String textCostAgreementENPhoneSum [] = {
            "Agreement",
            "Summary",
            "Traffic Details",
            "Charge Details",
            "Total, discount excluded",
            "Total, discount included",
            "Rates are indicated in UAH including VAT."
    };

    public final static String textCostAgreementRUPhoneAccDet [] = {
            "По номеру договора",
            "Трафик за текущий месяц",
            "Отчеты",
            "Суммарно",
            "Детализация трафика",
            "Детализация начислений",
    };

    public final static String textCostAgreementRUUnbilledDet [] = {
            "Трафик за текущий месяц",
            "Данные за последние два часа не отображаются в детализации вызовов за текущий месяц.",
            "Детализация трафика по номеру договора",

    };

    public final static String textCostReports [] = {
            "Отчеты",
            "История использования бонусов по договору",

    };

    //data for cost page <<


    //data for Profile page >>
    public final static String TITLE_PROFILE_RU = "Мой Киевстар - Настройки пользователя";

    public final static String LINKS_ON_PROFILE_RU[] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Пополнение счета",
            "Помощь",
            "Карта сайта"
    };

    public final static String textOnProfileRU [] = {
            "Логин:",
            "Имя:",
            "Фамилия:",
            "Отчество:",
            "Дата рождения:",
            "Пол:",
            "Номер договора:",
            "Лицевой счет:",
            "Область:",
            "Район:",
            "Населенный пункт:",
            "Улица:",
            "Дом:",
            "Квартира:",
            "Индекс:",
            "Мобильный телефон:",
            "Проверить номер мобильного телефона:",
            "Домашний телефон:",
            "Род занятий:",
            "Секретный вопрос:",
            "Адрес электронной почты:",
            "Проверить электронный адрес:"
    };

    //data for Profile page <<

    //data for Payment page >>
    public final static String TITLE_PAYMENT_RU = "Мой Киевстар - Платежи";

    public final static String LINKS_PAYMENT_RU [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",

    };
    public final static String TEXT_PAYMENT_RU [] = {
            "Платежи",
            "Дата",
            "Тип платежа",
            "Дополнительная информация",
            "Сумма, грн.",
            "Итого, грн.",
    };

    //data for Payment page <<

    //data for TSM overview page >>
    public final static String TITLE_TSM_RU = "Мой Киевстар - Управление услугами";
    public final static String TITLE_TSM_ARCHIVE_ORDERS = "Мой Киевстар - Архив заявок";

    public final static String LINKS_FEATURE_RU [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Управление услугами",
            "Архив заявок",
    };

    public final static String TEXT_FEUTURE_RU [] = {
            "Данные пользователя",
            "Состояние лицевого счета",
            "Тарифный пакет",
            "Дополнительные услуги",

    };

    //data for TSM overview page <<

    //data for Providers page >>
    public final static String TITLE_PROVIDERS_RU = "Мой Киевстар - Пополнение счета";
    public final static String TEXT_PROVIDERS_RU [] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Скретч-карта",
            "Портмоне.сом",
            "EasyPay",
            "Приватбанк"
    };

    //data for Providers page <<

    //data for Helps page >>
    public final static String TITLE_HELP_INSIDE_RU = "Мой Киевстар - Часто задаваемые вопросы";
    public final static String TITLE_HELP_INSIDE_MANUAL_RU = "Мой Киевстар - Руководство пользователя";
    public final static String TITLE_HELP_INSIDE_QUESTION_RU = "Мой Киевстар - Обратная связь";
    public final static String TITLE_HELP_INSIDE_CONDITIONS_RU = "Мой Киевстар - Условия использования";
    public final static String LINKS_HELP_RU[] = {
            "Обзор",
            "Затраты",
            "Профиль",
            "Платежи",
            "Услуги и акции",
            "Пополнение счета",
            "Помощь",
            "Карта сайта",
            "Часто задаваемые вопросы",
            "Руководство пользователя",
            "Обратная связь",
            "Условия использования",
    };

    //data for Helps page <<

    //data for Sitemap page >>
    public final static String TITLE_SITEMAP_RU = "Мой Киевстар - Карта сайта";
    public final static String TEXT_SITEMAP_RU [] = {
            "Обзор",
            "Затраты",
            "По номеру договора",
            "Суммарно",
            "Детализация трафика",
            "Детализация начислений",
            "Трафик за текущий месяц",
            "Отчеты",
            "Профиль",
            "Настройки пользователя",
            "Адресная книга",
            "Платежи",
            "Услуги и акции",
            "Управление услугами",
            "Перевод бонусов",
            "Архив заявок",
            "Пополнение счета",
            "Помощь",
            "Часто задаваемые вопросы",
            "Руководство пользователя",
            "Обратная связь",
            "Условия использования",
            "Карта сайта"
    };
}

