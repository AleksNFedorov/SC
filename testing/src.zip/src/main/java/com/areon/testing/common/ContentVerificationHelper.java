package com.areon.testing.common;

import com.areon.testing.common.context.TestContextService;
import com.areon.testing.common.context.TestMethodContext;
import com.areon.testing.common.old.UsageMethods;
import com.google.common.io.Files;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Reporter;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 12/3/13
 * Time: 10:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class ContentVerificationHelper extends UsageMethods {

    private static Logger LOG = LoggerFactory.getLogger(ContentVerificationHelper.class);

    public ContentVerificationHelper(TestContextService service) {
        super(service);
    }


    @Override
    public void clickOnElementBy(By by, String elementModifier) {
        LOG.debug("method invoked By [{}], modifier [{}]", by, elementModifier);
        try {
            RemoteWebDriver driver = testContextService.getDriver();
            doWebDriverWait();
            driver.findElement(by).click();
        } catch (Exception e) {
            LOG.error("Can't click element due to exception [{}]", e.getMessage());
            onFail(e.getMessage(), elementModifier);
        } finally {
            LOG.debug("method finished");
        }

    }

    @Override
    public void switchLocalisation(String[] compositeMessage) {
        String checkLocaleSelectedXPath = compositeMessage[0];
        String selectLocaleXpath = compositeMessage[1];
        String description = compositeMessage[2];
        LOG.debug("method invoked, [{}][{}]", checkLocaleSelectedXPath, selectLocaleXpath);
        try {
            RemoteWebDriver driver = testContextService.getDriver();
            doWebDriverWait();
            if (driver.findElements(By.xpath(checkLocaleSelectedXPath)).size() > 0) {
                LOG.info("Localization [{}] already selected", checkLocaleSelectedXPath);
            } else {
                LOG.debug("Trying to switch localization");
                driver.findElement(By.xpath(selectLocaleXpath)).click();
                LOG.info("Localization successfully switched");
            }
        } catch (Exception e) {
            LOG.error("Can't switch locale [{}]", e.getMessage());
            onFail(e.getMessage(), "Can't switch locale " + description);
        } finally {
            LOG.debug("method finished");
        }
    }

    @Override
    public void verifyTitle(String[] compositeMessage) {
        String title = compositeMessage[0];
        String description = compositeMessage[1];
        LOG.debug("method invoked, [{}]", compositeMessage);
        try {
            RemoteWebDriver driver = testContextService.getDriver();
            new WebDriverWait(driver, 5);
            if (driver.getTitle().contains(title)) {
                LOG.info("Title correct, title [{}]", title);
            } else {
                LOG.info("Title incorrect, expected title [{}], original title [{}]", title, driver.getTitle());
                onFail("Title incorrect", description);
            }
        } catch (Exception e) {
            LOG.error("Exception during title verification", e.getMessage());
            onFail(e.getMessage(), "Exception during title verification");
        } finally {
            LOG.debug("method finished");
        }

    }

    @Override
    public void verifyTextOnPage(String[][] dataToCheck) {
        LOG.debug("method invoked, elemens count [{}]", dataToCheck.length);

        try {
            for (String[] checkDataPair : dataToCheck) {
                String textDataToCheck = checkDataPair[Locators.TestDataContainer.TestContent.ordinal()];
                String textDataToCheckDescription = checkDataPair[Locators.TestDataContainer.TestContentDescription.ordinal()];
                verifyElementContent(textDataToCheck, textDataToCheckDescription);
            }
        } catch (Exception e) {
            LOG.error("Exception during text verification", e.getMessage());
            onFail(e.getMessage(), "Exception during text verification");
        } finally {
            LOG.debug("method finished");
        }
    }

    @Override
    public void verifyClickableElements(String s) {
        LOG.debug("method invoked, [{}]", s);
        RemoteWebDriver driver = testContextService.getDriver();
        new WebDriverWait(driver, 5);

        List<WebElement> list = driver.findElements(By.xpath(s));
        for (WebElement item : list) {
            if (item.isDisplayed()) {
                item.click();
                LOG.info("Checkbox is clickable");
            } else {
                LOG.info("Checkbox [{}] is no active", item);
            }
        }
    }

    private void verifyElementContent(String text, String textDescription) {
        LOG.debug("method invoked, text [{}], description [{}]", text, textDescription);
        try {
            RemoteWebDriver driver = testContextService.getDriver();
            new WebDriverWait(driver, 5);

            if ((driver.findElement(By.xpath(Locators.pageXpath))).getText().contains(text)) {
                LOG.info("Text present on page, text [{}], description [{}]", text, textDescription);
            } else {
                LOG.info("Text does not present on page, text [{}], description [{}]", text, textDescription);
                onFail("Text does not present on page", textDescription);
            }
        } catch (Exception e) {
            LOG.error("Exception during text verification", e.getMessage());
            onFail(e.getMessage(), "Exception during text verification");
        } finally {
            LOG.debug("method finished");
        }
    }


    @Override
    public void downloadReport(String format, String downloadButtonXPath, String downloadButtonModifier) {
        RemoteWebDriver driver = testContextService.getDriver();
        try {
            doWebDriverWait(ExpectedConditions.visibilityOfElementLocated(By.xpath(Locators.formSelectDownloadFile)));

            new Select(driver.findElement(By.xpath(Locators.formSelectDownloadFile))).selectByVisibleText(format);
            clickOnElementBy(By.xpath(downloadButtonXPath), downloadButtonModifier);

            if (driver.getCurrentUrl().contains(Locators.GO_TO_BASE_URL + "/tbmb/view/download.do")) {
                throw new RuntimeException("Empty report [" + format + "]");
            } else {
                LOG.info("Success report of [{}] format!",format);
            }
        } catch (Exception e) {
            LOG.error("Exception during report downloading");
            onFail(e.getMessage(), downloadButtonModifier);
        } finally {
            driver.navigate().back();
        }
    }

    public void onFail(String failMessage, String failDescription) {
        LOG.debug("method invoked");
        try {
            TestMethodContext context = testContextService.getCurrentTestMethodContext();
            context.setMethodFailed(failMessage + " - " + failDescription);
            Reporter.log("<div>Test method [" + context.getTestMethod().getName() + "], fail reason [" + failMessage + "][" + failDescription + "]</div>");
            makeScreenShot(Locators.ResultType.Fail, failDescription);
        } catch (Exception ex) {
            LOG.error("Exceptions during invoking onFail method ", ex);
        } finally {
            LOG.debug("method finished");
        }
    }

    private void makeScreenShot(Locators.ResultType result, String description) throws IOException {
        LOG.debug("method invoked");
        File resultFolder = testContextService.getFolderForResult(result);
        File screenshotTempFile = ((TakesScreenshot) testContextService.getDriver()).getScreenshotAs(OutputType.FILE);
        File reportScreenShotFile = new File(resultFolder, buildScreenShotFileName(description));
        Files.move(screenshotTempFile, reportScreenShotFile);
        Reporter.log("<a href='" + reportScreenShotFile.getAbsolutePath() + "'>" + " screenshot</a>");
        LOG.debug("method finished");
    }

    private String buildScreenShotFileName(String description) {

        Pattern notChars = Pattern.compile("\\W");
        String normalizedDEscription = description.replaceAll(notChars.pattern(), "_");

        TestMethodContext context = testContextService.getCurrentTestMethodContext();
        String resultFileName = context.getTestMethod().getName() + "_" + normalizedDEscription + ".png";
        resultFileName = resultFileName.toLowerCase().replace(" ", "_");
        return resultFileName;
    }

    public void checkWrongPageAndForward(String[] checkparams) {
        String textToLookUp = checkparams[0];
        String description = checkparams[1];

        LOG.debug("method invoked, [{}]", textToLookUp);
        try {
            if (isElementPresentByText(textToLookUp)) {
                LOG.info("Text has been found [{}]", textToLookUp);
                testContextService.getDriver().navigate().back();
                LOG.info("Forward in back");
            }
        } catch (Exception ex) {
            LOG.error("Exception during cheking wrong page, [{}]", description);
            onFail(ex.getMessage(), "Exception during cheking wrong page " + description);
        }finally {
            LOG.debug("method finished");
        }

    }

    private void doWebDriverWait(ExpectedCondition conditions) {
        new WebDriverWait(testContextService.getDriver(), testContextService.getWebDriverWait()).until(conditions);
    }

    private void doWebDriverWait() {
        new WebDriverWait(testContextService.getDriver(), testContextService.getWebDriverWait());
    }


}
