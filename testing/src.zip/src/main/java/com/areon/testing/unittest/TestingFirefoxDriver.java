package com.areon.testing.unittest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: Iaremenkoand
 * Date: 20.11.13
 * Time: 15:11
 * To change this template use File | Settings | File Templates.
 */
@Test
public class TestingFirefoxDriver {

    public void runStartingPage() {

        WebDriver driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        final String sUrl = "http://my.kyivstar.net";
        driver.get(sUrl);
        WebElement oSerch = driver.findElement(By.xpath(".//*[@id='login']"));
        oSerch.sendKeys("+380975310412");
        WebElement oInpt = driver.findElement(By.xpath(".//*[@id='password']"));
        oInpt.sendKeys("SelfCare");
        WebElement oBut = driver.findElement(By.xpath(".//*[@id='login_submit']"));
        oBut.click();

        driver.close();
    }

}
