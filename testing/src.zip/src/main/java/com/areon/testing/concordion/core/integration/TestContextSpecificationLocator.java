package com.areon.testing.concordion.core.integration;

import org.concordion.api.Resource;
import org.concordion.api.SpecificationLocator;
import org.concordion.internal.util.Check;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 01.01.14
 * Time: 13:36
 * To change this template use File | Settings | File Templates.
 */
public class TestContextSpecificationLocator implements SpecificationLocator {

    private final Logger LOG = LoggerFactory.getLogger(TestContextSpecificationLocator.class);


    @Override
    public Resource locateSpecification(Object fixture) {
        LOG.debug("method invoked [{}]", fixture);

        LOG.debug("Getting global test context");
        GlobalTestContext.SpecificationContext specificationContext = GlobalTestContext.getInstance().getCurrentTestContext();
        LOG.info("Test context aquired");
        LOG.debug("Test context [{}]", specificationContext);

        return buildSpecificationResource(specificationContext);
    }

    private Resource buildSpecificationResource(GlobalTestContext.SpecificationContext context) {
        LOG.debug("method invoked [{}]", context);
        Check.notNull(context, "Context is null");

        Resource invokerResource = context.getCurrentTestResource();
        String specificationHref = context.getSpecification().getLocation();

        Resource specificationResource = invokerResource.getRelativeResource(specificationHref);
        LOG.debug("method finished, [{}]", specificationResource);
        return specificationResource;
    }
}
