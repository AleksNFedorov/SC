package com.areon.testing.concordion.core.config;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 03.01.14
 * Time: 10:42
 * To change this template use File | Settings | File Templates.
 */
public class AJaxbTest {

    public static void main(String ... args) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(Suite.class);
        Object result = context.createUnmarshaller().unmarshal(AJaxbTest.class.getClassLoader().getResourceAsStream("testsuite.xml"));
        System.out.println(((Suite)result).tests);
    }
}
