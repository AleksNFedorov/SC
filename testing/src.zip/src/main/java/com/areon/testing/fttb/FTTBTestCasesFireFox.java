package com.areon.testing.fttb;

import com.areon.testing.common.old.FireFoxCoreTest;
import com.areon.testing.common.Locators;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class FTTBTestCasesFireFox extends FireFoxCoreTest {


    private static final Logger LOG = LoggerFactory.getLogger(FTTBTestCasesFireFox.class);

/*

    @Test(priority = 1)
    public void testcase_1_FTTB_OverviewPage() {

        

        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_OVERVIEW_RU);
        method.verifyTextOnPage(UseData.linksOverviewPageRu);
        method.verifyTextOnPage(UseData.textOverviewPageRu);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(UseData.TITLE_OVERVIEW_UA);
        method.verifyTextOnPage(UseData.LINKS_OVERVIEW_PAGE_UA);
        method.verifyTextOnPage(UseData.textOverviewPageUa);

        method.switchLocalisation(Locators.localEnXpath);
        method.verifyTitle(UseData.TITLE_OVERVIEW_EN);
        method.verifyTextOnPage(UseData.linksOverviewPageEn);
        method.verifyTextOnPage(UseData.textOverviewPageEn);

        method.takeScreenshot("testcase_1_FTTB_OverviewPage");
    }

    @Test(priority = 2)
    public void testcase_2_FTTB_Statement_Agr() {

        
        driver.get(UseData.BASE_URL + "/tbmb/hi/view/wireless_number_summary.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.titleCostAgreementRU);
        method.verifyTextOnPage(UseData.linksCostAgreementRU);
        method.verifyTextOnPage(UseData.textCostAgreementRUPhoneSum);

        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(UseData.titleCostAgreementUA);
        method.verifyTextOnPage(UseData.linksCostAgreementUA);
        method.verifyTextOnPage(UseData.textCostAgreementUAPhoneSum);

        method.switchLocalisation(Locators.localEnXpath);
        method.verifyTitle(UseData.titleCostAgreementEN);
        method.verifyTextOnPage(UseData.linksCostAgreementEN);
        method.verifyTextOnPage(UseData.textCostAgreementENPhoneSum);

        method.takeScreenshot("testcase_2_FTTB_Statement_Agr");

    }

    @Test(priority = 3)
    public void testcase_FTTB_3_Statement_Acc_Detailed() {

        
        driver.get(UseData.BASE_URL + "/tbmb/hi/view/account_detailed_traffic.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.titleCostAgreementRU);
        method.verifyTextOnPage(UseData.linksCostAgreementRU);
        method.verifyTextOnPage(UseData.textCostAgreementRUPhoneAccDet);

        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.takeScreenshot("testcase_FTTB_3_Statement_Acc_Detailed");

    }

    @Test(priority = 4)
    public void testcase_FTTB_4_Statement_Acc_Det_Charge() {

        
        driver.get(UseData.BASE_URL + "/tbmb/hi/view/account_detailed_charge.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.titleCostAgreementRU);
        method.verifyTextOnPage(UseData.linksCostAgreementRU);
        method.verifyTextOnPage(UseData.textCostAgreementRUPhoneSum);

        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.takeScreenshot("testcase_FTTB_4_Statement_Acc_Det_Charge");
    }

    @Test(priority = 5)
    public void testcase_FTTB_5_Statement_unbilled_usage() {

        
        driver.get(UseData.BASE_URL + "/tbmb/hi/view/unbilled_usage.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.titleCostUnbilledRU);
        method.verifyTextOnPage(UseData.linksCostAgreementRU);
        method.verifyTextOnPage(UseData.textCostAgreementRUUnbilledDet);

        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.takeScreenshot("testcase_FTTB_5_Statement_unbilled_usage");

    }

    @Test(priority = 6)
    public void testcase_FTTB_6_Statement_Reports() {

        
        driver.get(UseData.BASE_URL + "/tbmb/reports/bonus/show.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.titleCostReportRU);
        method.verifyTextOnPage(UseData.linksCostAgreementRU);
        method.verifyTextOnPage(UseData.textCostReports);

        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.takeScreenshot("testcase_FTTB_6_Statement_Reports");

    }

    @Test(priority = 7)
    public void testcase_FTTB_7_Profile() {

        
        driver.get(UseData.BASE_URL + "/tbmb/inet/com.areon.testing.contract/profile/show.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_PROFILE_RU);
        method.verifyTextOnPage(UseData.LINKS_ON_PROFILE_RU);
        method.verifyTextOnPage(UseData.textOnProfileRU);

        if (method.isElementPresentByXpath(Locators.GENERAL_EDIT_BUTTON)) {
            method.clickOnElementXpath(Locators.GENERAL_EDIT_BUTTON);

            method.fillTextField("./*/
/*[@id='firstName_field']", "TestName");
            method.fillTextField("./*/
/*[@id='lastName_field']", "TestSubname");
            method.fillTextField("./*/
/*[@id='email_field']", "test@test.test");

            if (method.isElementPresentByXpath("./*/
/*[@id='saveBtn']")) {
                method.clickOnElementXpath("./*/
/*[@id='saveBtn']");

                if (method.isElementPresentByXpath(Locators.greenMessage)) {
                    LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                    method.takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                    LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                    method.takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                } else {
                    LOG.info("No message");
                    method.takeScreenshot("No message");
                }
            } else {
                LOG.info("Save button absence");
            }
        } else {
            LOG.info("Element absence");
        }

    }

    @Test(priority = 8)
    public void testcase_FTTB_8_Personal_Address_Book() {

        
        driver.get(UseData.BASE_URL + "/tbmb/profile/personal_address_book.do");
        new WebDriverWait(driver, 10);



    }

    @Test(priority = 9)
    public void testCase_FTTB_9_Payment_activity() {

        
        driver.get(UseData.BASE_URL + "/tbmb/inet/com.areon.testing.contract/payment/activity/show.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_PAYMENT_RU);
        method.verifyTextOnPage(UseData.LINKS_PAYMENT_RU);
        method.verifyTextOnPage(UseData.TEXT_PAYMENT_RU);

        method.generateReport();
    }

    @Test(priority = 10)
    public void testCase_FTTB_10_Tsm_Overview() {

        
        driver.get(UseData.BASE_URL + "/tbmb/tsm/overview.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_TSM_RU);
        method.verifyTextOnPage(UseData.LINKS_FEATURE_RU);
        method.verifyTextOnPage(UseData.TEXT_FEUTURE_RU);

        method.takeScreenshot("Feature page RU");

    }

    @Test(priority = 11)
    public void testCase_FTTB_11_Tsm_Archive_Orders() {

        
        driver.get(UseData.BASE_URL + "/tbmb/tsm/archiveOrders.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_TSM_ARCHIVE_ORDERS);
        method.verifyTextOnPage(UseData.LINKS_FEATURE_RU);
        //method.verifyTextOnPage(UseData.);
        method.takeScreenshot("Archive Orders com.areon.testing.com.areon.testing.fttb page RU");

        method.changeFeature();

    }

    @Test(priority = 12)
    public void testCase_FTTB_12_Providers() {

        
        driver.get(UseData.BASE_URL + "/tbmb/help/providers_reg.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_PROVIDERS_RU);
        method.verifyTextOnPage(UseData.TEXT_PROVIDERS_RU);

        method.takeScreenshot("Providers Page RU");

        method.verifyElementValue("./*/
/*[@id='mainContentBlock']/p[1]/a", "Скретч-карта", "Provider |");
        method.verifyElementValue("./*/
/*[@id='mainContentBlock']/p[2]/a", "Портмоне.сом", "Provider |");
        method.verifyElementValue("./*/
/*[@id='mainContentBlock']/p[3]/a", "EasyPay", "Provider |");
        method.verifyElementValue("./*/
/*[@id='mainContentBlock']/p[4]/a", "Приватбанк", "Provider |");

    }

    @Test(priority = 13)
    public void testCase_FTTB_13_Help_Inside_FAQ() {

        
        driver.get(UseData.BASE_URL + "/tbmb/help_inside/faq.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_HELP_INSIDE_RU);
        method.verifyTextOnPage(UseData.LINKS_HELP_RU);

        method.takeScreenshot("Help FAQ page RU ");

    }

    @Test(priority = 14)
    public void testCase_FTTB_14_Help_Inside_userManual() {

        
        driver.get(UseData.BASE_URL + "/tbmb/help_inside/userManual.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_HELP_INSIDE_MANUAL_RU);
        method.verifyTextOnPage(UseData.LINKS_HELP_RU);

        method.takeScreenshot("Help User Manual page RU");
    }

    @Test(priority = 15)
    public void testCase_FTTB_15_Help_Inside_sendQuestion() {

        
        driver.get(UseData.BASE_URL + "/tbmb/help_inside/sendQuestion/show.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_HELP_INSIDE_QUESTION_RU);
        method.verifyTextOnPage(UseData.LINKS_HELP_RU);

        method.takeScreenshot("Help Send Questions page RU");
    }

    @Test(priority = 16)
    public void testCase_FTTB_16_Help_Inside_termsConditionsHI() {

        
        driver.get(UseData.BASE_URL + "/tbmb/help_inside/termsConditionsHI.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_HELP_INSIDE_CONDITIONS_RU);
        method.verifyTextOnPage(UseData.LINKS_HELP_RU);

        method.takeScreenshot("Help Terms Conditions HI page RU");
    }

    @Test(priority = 17)
    public void testCase_FTTB_17_Sitemap() {

        
        driver.get(UseData.BASE_URL + "/tbmb/sitemap/show.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(UseData.TITLE_SITEMAP_RU);
        method.verifyTextOnPage(UseData.TEXT_SITEMAP_RU);

        method.takeScreenshot("Sitemap page RU");
    }

*/
}
