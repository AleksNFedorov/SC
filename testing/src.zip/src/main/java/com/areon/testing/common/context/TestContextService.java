package com.areon.testing.common.context;

import com.areon.testing.common.Locators;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 12/3/13
 * Time: 9:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class TestContextService {

    public static final int DEFAULT_WEB_DRIVER_WAIT = 2;

    private TestMethodContext testMethodContext;

    private final Locators.Segment segment;
    private final Locators.Browser browser;
    private RemoteWebDriver driver;

    private File successResultScreenShotFolder;
    private File failResultScreenShotFolder;


    public TestContextService(String segment, String  browser) throws Exception {
        this.segment = Locators.Segment.valueOf(segment);
        this.browser = Locators.Browser.valueOf(browser);
        init();
    }

    private void init() throws Exception {
        driver = new BrowserDriverService().createDriver(this.browser);
        initOutputFolder();
    }

    public int getWebDriverWait() {
        return DEFAULT_WEB_DRIVER_WAIT;
    }


    public RemoteWebDriver getDriver() {
        return driver;
    }

    public void createMethodContext(Method method) {
        testMethodContext = new TestMethodContext(method, browser, segment);
    }

    public void destroyMethodContext() {
        testMethodContext = null;
    }

    public void destroyTest() {
        driver.quit();
    }

    public TestMethodContext getCurrentTestMethodContext() {
        return testMethodContext;
    }

    public File getFolderForResult(Locators.ResultType result) {
        switch (result) {
            case Fail:
                return failResultScreenShotFolder;
            case Success:
                return successResultScreenShotFolder;
            default:
                throw new RuntimeException("Unknown report folder type ["+result+"]");
        }
    }

    private void initOutputFolder() throws IOException {

        String reportFolderPath = Locators.getApplicationProperty(Locators.REPORT_FOLDER);
        File reportFolder = new File(reportFolderPath, "screenshots");
        File successFolder = new File(reportFolder, Locators.ResultType.Success+File.separator+segment.name()+File.separator+browser.name());
        File failFolder = new File(reportFolder, Locators.ResultType.Fail+File.separator+segment.name()+File.separator+browser.name());

        tryCrateFolder(successFolder);
        tryCrateFolder(failFolder);

        failResultScreenShotFolder = failFolder;
        successResultScreenShotFolder = successFolder;

    }

    private void tryCrateFolder(File folderFile) throws IOException {
        if(!folderFile.exists()) {
            if(!folderFile.mkdirs())
                throw new IOException("Can`t create report folder");
        } else if(!folderFile.isDirectory()) {
            throw new IOException("File with report folder name exist, can`t create folder");
        }
    }

}
