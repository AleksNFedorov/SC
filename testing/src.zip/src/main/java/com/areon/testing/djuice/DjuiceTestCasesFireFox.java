package com.areon.testing.djuice;

import com.areon.testing.common.Data;
import com.areon.testing.common.old.FireFoxCoreTest;
import com.areon.testing.common.Locators;
import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class DjuiceTestCasesFireFox extends FireFoxCoreTest {

    private static Logger LOG = LoggerFactory.getLogger(DjuiceTestCasesFireFox.class);

/*    @BeforeClass
    public void initDriver() {
        LOG.info("initDriver start");

        try {
            //go to test page
            driver.get(Data.BASE_URL);
            try {
//                driver.findElement(By.xpath(Locators.localRuXpath)).click();
            } catch (Exception e) {
            }

            //login on system
            WebElement searchField = driver.findElement(By.xpath(Locators.loginFormXpath));
            searchField.clear();
            searchField.sendKeys(Locators.getApplicationProperty(Locators.DJUICE_LOGIN));
            WebElement searchField2 = driver.findElement(By.name(Locators.passwordFormName));
            searchField2.clear();
            searchField2.sendKeys(Locators.getApplicationProperty(Locators.DJUICE_PASSWORD));
            WebElement searchButton = driver.findElement(By.name(Locators.submitButtonName));
            searchButton.click();

            if (method.isElementPresentByXpath("./*//*[@id='errorsTable']")) {
                LOG.info("Error on Login Page: " + driver.findElement(By.xpath("./*//*[@id='errorsTable']")).getText());
            } else {
            }
        } catch (Exception e) {
            LOG.error("Exception during driver inialization", e);
        }

    }*/

    /*
    //verifying on timeout session
    public void verifyTimeout() {

        if (method.isElementPresentByText(getMessage(Data.VERIFY_TIMEOUT_PAGE,LOCALE_RU))) {
            LOG.info("Start browser correct");
        } else {
            LOG.info("Start browser incorrect");
            Assert.fail("Timeout exception");

        }
    }
    */

    @Test(priority = 1)
    //test case verify UI on overview page
    public void TestCaseOverviewPage() {

/*        //verifyTimeout();
        boolean testPassed = true;
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_OVERVIEW_DJUICE, Locators.LOCALE_RU));
        //method.verifyTitle(Data.TITLE_OVERVIEW_DJUICE_RU);
        testPassed &= method.isTextOnPageCorrect(Data.linksOverviewPageRu);
        method.verifyTextOnPage(Data.textOverviewPageRu);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.TITLE_OVERVIEW_DJUICE_UA);
        testPassed &= method.isTextOnPageCorrect(Data.linksOverviewPageUa);
        //method.verifyTextOnPage(Data.linksOverviewPageUa);
        method.verifyTextOnPage(Data.textOverviewPageUa);

        method.takeScreenshot("TC_1_OverviewPage");

        Assert.assertFalse("Test failed", Boolean.TRUE.equals(testPassed));*/
    }

    /*
    @Test(priority = 1)
    public void TestCaseCostPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/b2c/view/wireless_number_summary.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.TITLE_COST_DJUICE_RU);
        method.verifyTextOnPage(Data.linksCostPageRu);
        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.TITLE_COST_DJUICE_UA);
        method.verifyTextOnPage(Data.linksCostPageUa);

        method.takeScreenshot("TC_2_CostPage");
    }

    @Test(priority = 2)
    public void TC_3_DetailedUsagePage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/b2c/view/detailed_usage.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.TITLE_DETAIL_USAGE_RU);
        method.verifyTextOnPage(Data.linksCostPageRu);

        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.TITLE_DETAIL_USAGE_UA);
        method.verifyTextOnPage(Data.linksCostPageUa);

        method.takeScreenshot("TC_3_DetailedUsagePage");
    }

    @Test(priority = 3)
    public void TC_4_UnbilledUsagePage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/view/unbilled_usage.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.TITLE_UNBILL_USAGE_RU);
        method.verifyTextOnPage(Data.linksCostPageRu);

        method.getReport(Locators.receiveButtonRu, Locators.confirmButtonRu);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.TITLE_UNBILL_USAGE_UA);
        method.verifyTextOnPage(Data.linksCostPageUa);
        new WebDriverWait(driver, 10);

        method.getReport(Locators.receiveButtonUa, Locators.confirmButtonUa);

        method.takeScreenshot("TC_4_UnbilledUsagePage");
    }

    @Test(priority = 4)
    public void TC_5_WirelessNumberPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/view/wireless_number_chrgs.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.titleWirelessNumberChrgsRu);
        method.verifyTextOnPage(Data.linksCostPageRu);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.titleWirelessNumberChrgsUa);

        method.verifyTextOnPage(Data.linksCostPageUa);

        method.takeScreenshot("TC_5_WirelessNumber");
    }

    @Test(priority = 5)
    public void TC_6_ReportsPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/b2c/view/reports.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.titleReportsRu);
        method.verifyTextOnPage(Data.linksCostPageRu);

        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.titleReportsUa);
        method.verifyTextOnPage(Data.linksCostPageUa);
    }


    @Test(priority = 6)
    public void TC_7_PersonalProfilePage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/b2c/profile/personal_profile.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.titlePersonalProfileRu);
        method.verifyTextOnPage(Data.linksPersonalProfileRu);

        method.verifyTextOnPage(Data.textPersonalProfileRu);

        if (method.isElementPresentByXpath(Locators.editButtonRu)) {
            method.clickOnElementXpath(Locators.editButtonRu);

            method.fillTextField(".//*[@id='firstName_field']", "TestName");
            method.fillTextField(".//*[@id='lastName_field']", "TestSubname");
            method.fillTextField(".//*[@id='email_field']", "test@test.test");

            if (method.isElementPresentByXpath(".//*[@id='saveBtn']")) {
                method.clickOnElementXpath(".//*[@id='saveBtn']");

                if (method.isElementPresentByXpath(Locators.greenMessage)) {
                    LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                    method.takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                    LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                    method.takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                } else {
                    LOG.info("No message");
                    method.takeScreenshot("No message");
                }
            } else {
                LOG.info("Save button absence");
            }
        } else {
            LOG.info("Element absence");
        }

        method.clickOnlinkText(Data.linkPersonalProfileRU);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.titlePersonalProfileUa);
        method.verifyTextOnPage(Data.linksPersonalProfileUa);
    }


    @Test(priority = 7)
    public void TC_8_NotificationsPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/profile/notifications.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.titleNotificationsRu);
        method.verifyTextOnPage(Data.linksPersonalProfileRu);
        method.verifyTextOnPage(Data.textNotificationsRu);

        if (method.isElementPresentByXpath(Locators.saveButtonRu)) {
            LOG.info("Save button present");
            if (driver.findElement(By.xpath(Locators.saveButtonRu)).isDisplayed()) {
                LOG.info("Save button isDisplayed");
            } else {
                LOG.info("Save button not Displayed");
            }
        } else {
            LOG.info("Save button absence");
            method.takeScreenshot("Save button absence");
        }

        method.verifySizeElements("//input[@type='checkbox']", 6, "checkbox");

        List<WebElement> list = driver.findElements(By.xpath("//input[@type='checkbox']"));
        for (WebElement item : list) {
            if (item.isDisplayed()) {
                item.click();
                LOG.info("Checkbox is clicable");
            } else {
                LOG.info("Checkbox " + item + " no active");
            }
        }

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.titleNotificationsUa);
        method.verifyTextOnPage(Data.linksPersonalProfileUa);
    }


    @Test(priority = 8)
    public void TC_9_PersonalAddressBookPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/profile/personal_address_book.do");
        new WebDriverWait(driver, 10);

        Integer t1 = driver.findElements(By.xpath("//input[@type='checkbox']")).size();
        LOG.info("intValue" + t1.intValue());

        driver.get("https://my.djuice.ua/tbmb/addressbook/pab-addnew/show.do");
        new WebDriverWait(driver, 5);

        String dateFormat = "MM.dd_h.mm.ss";
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat SDF = new SimpleDateFormat(dateFormat);
        String randomNumber = SDF.format(cal.getTime());

        method.fillTextField(".//*[@name='phoneNumber']", randomNumber);
        method.fillTextField(".//*[@name='alias']", randomNumber);
        method.fillTextField(".//*[@name='name']", randomNumber);

        if (method.isElementPresentByXpath(Locators.saveButtonRu)) {
            method.clickOnElementXpath(Locators.saveButtonRu);

            if (method.isElementPresentByXpath(Locators.greenMessage)) {
                LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                method.takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
            } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                method.takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
            } else {
                LOG.info("No message");
                method.takeScreenshot("No message");
            }
        } else {
            LOG.info("SaveButton absence");
        }

        //method.clickOnlinkText(Data.linkAddressBookRU);
        driver.get("https://my.djuice.ua/tbmb/profile/personal_address_book.do");

        List<WebElement> list = driver.findElements(By.xpath("//input[@type='checkbox']"));
        for (WebElement x : list) {
            if (x.isDisplayed()) {
                x.click();
                if (method.isElementPresentByXpath(Locators.deleteButtonRu)) {
                    method.clickOnElementXpath(Locators.deleteButtonRu);
                    if (method.isElementPresentByXpath(".//*[@type='submit']")) {
                        method.clickOnElementXpath(".//*[@type='submit']");
                        LOG.info("All contacts delete");
                        return;
                    } else {
                        LOG.info("SubmitButton not Displayed");
                        return;
                    }
                } else {
                    LOG.info("DeleteButton not Displayed");
                    return;
                }
            } else {
                LOG.info("Checkbox not Displayed");
                return;
            }
        }
    }


    @Test(priority = 9)
    public void TC_10_PaymentPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/payment/activity/show.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.titlePaymentRu);
        method.verifyTextOnPage(Data.linksPaymentRu);

        method.generateReport();

        method.verifyTextOnPage(Data.textPaymentRu);
    }

    @Test(priority = 10)
    public void TC_11_OverviewPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/tsm/overview.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.titleFeaturePageRu);
        method.verifyTextOnPage(Data.linksFeatureRu);
        method.takeScreenshot("Feature page RU");

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.titleFeaturePageUa);
        method.verifyTextOnPage(Data.linksFeatureUa);
        method.takeScreenshot("Feature page UA");
    }

    @Test(priority = 11)
    public void TC_12_ArchiveOrdersPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/tsm/archiveOrders.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.titleArchiveOrdersRu);
        method.verifyTextOnPage(Data.linksFeatureRu);
        method.takeScreenshot("Archive Orders page RU");

        method.changeFeature();

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.titleArchiveOrdersUa);
        method.verifyTextOnPage(Data.linksFeatureUa);
        method.takeScreenshot("Archive Orders page UA");

    }


    @Test(priority = 12)
    public void TC_13_MobileCommunicationPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/involvements/documents/mobileCommunicationSA_dj/show.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(Data.titleCommunicationRu);
        method.verifyTextOnPage(Data.linksCommunicationRu);
        method.takeScreenshot("Communication page RU");

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.titleCommunicationUa);
        method.verifyTextOnPage(Data.linksCommunicationUa);
        method.takeScreenshot("Communication page UA");
    }

    @Test(priority = 13)
    public void TC_14_AppFormPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/involvements/documents/appForm_dj/show.do");
        new WebDriverWait(driver, 5);

        method.verifyTitle(Data.titleAppFormRu);
        method.verifyTextOnPage(Data.linksAppFormRu);
        method.takeScreenshot("Application form page RU");

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.titleAppFormUa);
        method.verifyTextOnPage(Data.linksAppFormUa);
        method.takeScreenshot("Application form UA");
    }


    @Test(priority = 14)
    public void TC_15_MoneyTransferPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/moneyTransfer/show.do");
        new WebDriverWait(driver, 5);

        method.verifyTitle(Data.titleMoneyTransferRu);
        method.verifyTextOnPage(Data.linksMoneyTransferRu);

        method.fillTextField(".//*[@id='phone']", "971202020");
        method.fillTextField(".//*[@id='transferAmount']", "1");

        for (int i = 0; i < 3; i++) {
            if (method.isElementPresentByXpath(Locators.submitButton)) {
                driver.findElement(By.xpath(Locators.submitButton)).click();
                continue;
            } else if (method.isElementPresentByXpath(Locators.greenMessage)) {
                LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                method.takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                break;
            } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                method.takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                break;
            } else {
                LOG.info("Nothing");
                break;
            }
        }

        driver.get("https://my.djuice.ua/tbmb/moneyTransfer/show.do");

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(Data.titleMoneyTransferUa);
        method.verifyTextOnPage(Data.linksMoneyTransferUa);
    }

    @Test(priority = 15)
    public void TC_16_ProvidersPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/help/providers_reg.do");
        new WebDriverWait(driver, 5);

        method.verifyTitle(Data.titleMoneyProvidersRu);
        method.verifyTextOnPage(Data.linksMoneyTransferRu);
        method.takeScreenshot("Money providers page RU");

        method.verifyElementValue(".//*[@href='/tbmb/balance_recharge.do?provider=0']", "Портмоне.сом", "Provider |");
        method.verifyElementValue(".//*[@href='/tbmb/balance_recharge.do?provider=1']", "EasyPay", "Provider |");
        method.verifyElementValue(".//*[@href='/tbmb/balance_recharge.do?provider=2']", "Приватбанк", "Provider |");

        method.switchLocalisation(Locators.localUaXpath);
        driver.get("https://my.djuice.ua/tbmb/help/providers_reg.do");
        new WebDriverWait(driver, 5);
        method.verifyTitle(Data.titleMoneyProvidersUa);
        method.verifyTextOnPage(Data.linksMoneyTransferUa);
        method.takeScreenshot("Money providers page UA");
    }

    @Test(priority = 16)
    public void TC_17_SendQuestionPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/help_inside/sendQuestion/show.do");
        new WebDriverWait(driver, 5);

        method.verifyTitle(Data.titlesendQuestionRu);
        method.verifyTextOnPage(Data.linkssendQuestionRu);
        method.takeScreenshot("Send question page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);
        method.verifyTitle(Data.titlesendQuestionUa);
        method.verifyTextOnPage(Data.linkssendQuestionUa);
        method.takeScreenshot("Send question page UA");

    }


    @Test(priority = 17)
    public void TC_18_FaqPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/help_inside/faq.do");
        new WebDriverWait(driver, 5);

        method.verifyTitle(Data.titleFaqRu);
        method.verifyTextOnPage(Data.linkssendQuestionRu);
        method.verifyTextOnPage(Data.linksFaqRu);
        method.takeScreenshot("Faq page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);
        method.verifyTitle(Data.titleFaqRu);
        method.verifyTextOnPage(Data.linkssendQuestionUa);
        method.verifyTextOnPage(Data.linksFaqUa);
        method.takeScreenshot("Faq page UA");

    }

    @Test(priority = 18)
    public void TC_19_UserManualPage() {



        method.switchLocalisation(Locators.localRuXpath);
        driver.get(Data.BASE_URL + "/tbmb/help_inside/userManual.do");
        new WebDriverWait(driver, 5);

        method.verifyTitle(Data.titleUserManualRu);
        method.verifyTextOnPage(Data.linkssendQuestionRu);
        method.takeScreenshot("UserManual page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);
        method.verifyTitle(Data.titleUserManualUa);
        method.verifyTextOnPage(Data.linkssendQuestionUa);
        method.takeScreenshot("UserManual page UA");
    }

    @Test(priority = 19)
    public void TC_20_TermsConditionsPage() {



        method.switchLocalisation(Locators.localRuXpath);
        driver.get(Data.BASE_URL + "/tbmb/help_inside/termsConditions.do");
        new WebDriverWait(driver, 5);

        method.verifyTitle(Data.titleTermsConditionsRu);
        method.verifyTextOnPage(Data.linkssendQuestionRu);
        method.takeScreenshot("Terms Conditions page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);
        method.verifyTitle(Data.titleTermsConditionsUa);
        method.verifyTextOnPage(Data.linkssendQuestionUa);
        method.takeScreenshot("Terms Conditions page UA");
    }

    @Test(priority = 20)
    public void TC_21_SitemapPage() {



        method.switchLocalisation(Locators.localRuXpath);

        driver.get(Data.BASE_URL + "/tbmb/sitemap/show.do");
        new WebDriverWait(driver, 5);
        method.verifyTitle(Data.titleSitemapRu);
        method.verifyTextOnPage(Data.linksSitemapRu);
        method.takeScreenshot("Sitemap page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);
        method.verifyTitle(Data.titleSitemapUa);
        method.verifyTextOnPage(Data.linksSitemapUa);
        method.takeScreenshot("Sitemap page UA");
    }
*/
}
