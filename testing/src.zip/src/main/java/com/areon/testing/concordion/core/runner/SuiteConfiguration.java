package com.areon.testing.concordion.core.runner;

import com.areon.testing.concordion.core.WebCoreTest;
import com.areon.testing.concordion.core.config.Suite;
import com.areon.testing.concordion.core.config.Test;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import java.io.File;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 03.01.14
 * Time: 11:19
 * To change this template use File | Settings | File Templates.
 */
public class SuiteConfiguration {

    private Suite suite;
    private Map<Class<? extends WebCoreTest>, Test> testsMapping = new TreeMap<Class<? extends WebCoreTest>, Test>(new Comparator<Class<? extends WebCoreTest>>() {
        @Override
        public int compare(Class<? extends WebCoreTest> o1, Class<? extends WebCoreTest> o2) {
            return o1.getName().compareTo(o2.getName());
        }
    });

    private static SuiteConfiguration configuration;

    private SuiteConfiguration(String pathToConfiguration)  {
        try {
            suite = loadSuiteConfiguration(pathToConfiguration);
            initTestsMapping();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public static void initConfiguration(String pathToConfiguration)  {
        configuration = new SuiteConfiguration(pathToConfiguration);
    }

    public static SuiteConfiguration getInstance() {
        return configuration;
    }

    private Suite loadSuiteConfiguration(String pathToConfigurationFile) throws JAXBException {
        JAXBContext suiteContext = JAXBContext.newInstance(Suite.class);
        Suite restoredTestSuite = (Suite) suiteContext.createUnmarshaller().unmarshal(new File(pathToConfigurationFile));
        return restoredTestSuite;
    }

    private void initTestsMapping(){
        for (Test test : suite.getTests()) {
            testsMapping.put(test.getClazz(), test);
        }
    }

    public Collection<Test> getSuiteTests() {
        return suite.getTests();
    }

    public Test getTestByClass(Class clazz) {
        return testsMapping.get(clazz);
    }
}
