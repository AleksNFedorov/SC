package com.areon.testing.unittest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: Iaremenkoand
 * Date: 20.11.13
 * Time: 17:02
 * To change this template use File | Settings | File Templates.
 */
public class TestTmpClassExample {

    @Test()
    public void testCaseTempExample() {

        WebDriver driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://my.kyivstar.ua");

        driver.findElement(By.xpath(".//*[@id='login']")).sendKeys("4192956");
        driver.findElement(By.xpath(".//*[@id='password']")).sendKeys("SelfCare!@3");

        driver.findElement(By.xpath(".//*[@id='login_submit']")).click();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        driver.findElement(By.linkText("Профиль")).click();

        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        driver.findElement(By.xpath(".//*[@id='mainContentBlock']/table/tbody/tr[27]/td[2]/input")).click();

        driver.close();

    }
}
