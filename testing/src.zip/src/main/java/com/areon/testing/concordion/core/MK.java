package com.areon.testing.concordion.core;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created with IntelliJ IDEA.
 * User: MatsytskyiVo
 * Date: 13.01.14
 * Time: 17:44
 * To change this template use File | Settings | File Templates.
 */
public class MK extends WebCoreTest {
    private static final Logger LOG = LoggerFactory.getLogger(MK.class);
    /**
     * Метод проверяет нажат ли компонент меню, и если не нажат - кликает
     * @param mainBy - By меню, где нужно проверить елемент на нажатие
     * @param name - название пункта меню
     * @param path - патч к елементам меню (главный патч + патч = полный патч к елементу)
     * */
    public boolean clickIfNotClicked(By mainBy, String name, String path){
        LOG.debug("method invoked [{}], [{}]", mainBy, name);
        RemoteWebDriver driver = getCurrentTestDriver();
        WebElement mainMenu =  driver.findElement(mainBy);
        try {
            WebElement test = mainMenu.findElement(By.xpath("./"+path+"[contains(.,'"+name+"')]"));
            if(test!=null){
                 test.click();
                LOG.debug("Нажат елемент");
                return true;
            } else {
                LOG.debug("Елемент не найден");
                return false;
            }
        } catch (RuntimeException e) {
                LOG.error("Елемент не найден [{}]", e.getMessage(), e);
                throw e;
        } finally {
            LOG.debug("method finished");
        }


    }

    public By createByXpath(String xpath){
        return By.xpath(xpath);
    }
    public By createByName(String name){
        return By.name(name);
    }

    public By createById(String id){
        return By.id(id);
    }

}
