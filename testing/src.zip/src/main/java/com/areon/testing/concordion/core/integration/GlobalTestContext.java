package com.areon.testing.concordion.core.integration;

import com.areon.testing.concordion.core.config.Specification;
import com.areon.testing.concordion.core.config.Test;
import org.apache.http.annotation.NotThreadSafe;
import org.concordion.api.Resource;
import org.concordion.internal.util.Check;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Stack;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 01.01.14
 * Time: 13:16
 * To change this template use File | Settings | File Templates.
 */
@NotThreadSafe
public class GlobalTestContext {

    private static final Logger LOG = LoggerFactory.getLogger(GlobalTestContext.class);

    private static GlobalTestContext inst;

    private RemoteWebDriver driver;
    private Test test;

    private final Stack<SpecificationContext> contextStack = new Stack<SpecificationContext>();

    public class SpecificationContext {
        private final Resource currentTestResource;
        private final Specification specification;

        public SpecificationContext(Specification specification) {
            LOG.debug("Default constructor invoked");
            Check.notNull(specification, "Specification can't be null");
            currentTestResource = null;
            this.specification = specification;
        }

        private SpecificationContext(Resource currentTestResource, Specification specification) {
            LOG.debug("constructor invoked [{}], [{}]", currentTestResource, currentTestResource);
            Check.notNull(currentTestResource, "Test resource can't be null");
            Check.notNull(specification, "Specification can't be null");

            this.currentTestResource = currentTestResource;
            this.specification = specification;
        }

        public Resource getCurrentTestResource() {
            return currentTestResource;
        }

        public Specification getSpecification() {
            return specification;
        }

        public boolean isTopLevelTest() {
            return currentTestResource == null;
        }

        @Override
        public String toString() {
            return "SpecificationContext{" +
                    ", currentTestResource=" + currentTestResource +
                    ", specification=" + specification +
                    '}';
        }
    }

    public static void createGlobalContext(RemoteWebDriver driver, Test test) {
        LOG.debug("method invoked [{}]", driver);

        LOG.info("Initializing new context");
        inst = new GlobalTestContext(driver, test);
        LOG.info("test context instance created");
        LOG.debug("method finished");
    }

    public static GlobalTestContext getInstance() {
        LOG.debug("method invoked");
        return inst;
    }

    private GlobalTestContext(RemoteWebDriver driver, Test test) {
        LOG.debug("method invoked [{}], [{}]", driver, test);
        this.driver = driver;
        this.test = test;
        createTopLevelTestContext();
    }

    private void createTopLevelTestContext() {
        LOG.debug("method invoked");
        contextStack.push(new SpecificationContext(test.getSpecification()));
        LOG.info("top level test context created");
        LOG.debug("method finished");
    }

    public RemoteWebDriver getDriver() {
        LOG.debug("method invoked");
        return driver;
    }

    public Test getTest() {
        LOG.debug("method invoked");
        return test;
    }

    public void createNewTestContext(Resource resource, Specification specification) {
        LOG.debug("method invoked [{}], [{}]", resource, specification);
        SpecificationContext context = new SpecificationContext(resource, specification);
        LOG.info("new test context created [{}]", context);
        contextStack.push(context);
        LOG.debug("context stack has been updated, size [{}]", contextStack.size());
        LOG.debug("method finished");
    }

    public SpecificationContext getCurrentTestContext() {
        LOG.debug("method invoked");
        SpecificationContext currentSpecificationContext = contextStack.peek();
        LOG.debug("method finished");
        return currentSpecificationContext;
    }


    public void destroyCurrentTestContext() {
        LOG.debug("method invoked");
        contextStack.pop();
        LOG.debug("context stack has been updated [{}]", contextStack.size());
        LOG.debug("method finished");
    }

    @Override
    public String toString() {
        return "GlobalTestContext{" +
                "driver=" + driver +
                ", stack size='" + contextStack.size()
                + '}';
    }
}
