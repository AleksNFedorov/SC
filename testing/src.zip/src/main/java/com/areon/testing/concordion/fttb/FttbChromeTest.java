package com.areon.testing.concordion.fttb;

import com.areon.testing.concordion.core.MK;
import com.areon.testing.concordion.core.WebCoreTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 31.12.13
 * Time: 15:35
 * To change this template use File | Settings | File Templates.
 */
public class FttbChromeTest extends MK {
    private static final Logger LOG = LoggerFactory.getLogger(WebCoreTest.class);

    /**
     * Метод для проверки выбран ли главный пунк меню
     * скорость работы зашкаливает
     * елемент должен быть переопределен для каждого теста
     * @param name - название пункта меню (может быть только пункт главного меню)
     *             ВНИМАНИЕ! МЕТОДЫ ПОДХОДЯТ ТОЛЬКО ДЛЯ mk
     * */
    public boolean isMainMenuSelected(String name){
        RemoteWebDriver driver = getCurrentTestDriver();
        WebElement mainMenu =  driver.findElement(By.xpath("//*[@id=\"navigation\"]/td[1]/table/tbody/tr/td/table/tbody/tr"));
        try {
        List<WebElement> menuItems = mainMenu.findElements(By.tagName("b"));
               if(menuItems.size()>0){
                   if(name.equals(menuItems.get(0).getText())) return true;
               }
        } catch (RuntimeException e) {
            LOG.error("Can't switch locale [{}]", e.getMessage(), e);
            throw e;
        } finally {
            LOG.debug("method finished");

        }
        return false;
    }

    public boolean mainMenuSelected(String name, String xPath){
        if(isMainMenuSelected(name))
            {
                return true;
            }
        clickElementByXPath(xPath);
        return true;
    }

    public boolean isSecMenuSelected(String name){
        RemoteWebDriver driver = getCurrentTestDriver();
        WebElement mainMenu =  driver.findElement(By.xpath("//*[@id=\"navigation\"]/td[1]/table/tbody/tr/td/ul"));
        try {
            List<WebElement> menuItems = mainMenu.findElements(By.tagName("b"));
            if(menuItems.size()>0){
                if(name.equals(menuItems.get(0).getText())) return true;
            }
        } catch (RuntimeException e) {
            LOG.error("Can't switch locale [{}]", e.getMessage(), e);
            throw e;
        } finally {
            LOG.debug("method finished");

        }
        return false;
    }

    public boolean secMenuSelected(String name, String xPath){
        if(isSecMenuSelected(name))
        {
            return true;
        }
        clickElementByXPath(xPath);
        return true;
    }


    public boolean selectSecondMenuItem(String mainMenuItem, String mainXpath, String secMenuItem, String secXpath){
        mainMenuSelected(mainMenuItem,mainXpath);
        boolean result = secMenuSelected(secMenuItem,secXpath);
        return result;
    }

}
