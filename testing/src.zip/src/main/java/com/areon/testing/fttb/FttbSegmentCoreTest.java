package com.areon.testing.fttb;

import com.areon.testing.common.CoreTest;
import com.areon.testing.common.Data;
import com.areon.testing.common.Locators;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.Locale;

/**
 * Created with IntelliJ IDEA.
 * User: Iaremenkoand
 * Date: 10.12.13
 * Time: 20:47
 * To change this template use File | Settings | File Templates.
 */
public class FttbSegmentCoreTest extends CoreTest {

    private static Logger LOG = LoggerFactory.getLogger(FttbSegmentCoreTest.class);

    @BeforeTest(groups = {"internetExplorer", "chrome", "fireFox"})
    public void initDriver() {
        LOG.debug("initDriver start");

        RemoteWebDriver driver = getWebDriver();

        try {
            driver.get(Locators.getApplicationProperty(Locators.GO_TO_BASE_URL));

            //login on system
            WebElement searchField = driver.findElement(By.xpath(Locators.loginFormXpath));
            searchField.clear();
            searchField.sendKeys(Locators.getApplicationProperty(Locators.FTTB_LOGIN));
            WebElement searchField2 = driver.findElement(By.name(Locators.passwordFormName));
            searchField2.clear();
            searchField2.sendKeys(Locators.getApplicationProperty(Locators.FTTB_PASSWORD));
            WebElement searchButton = driver.findElement(By.name(Locators.submitButtonName));
            searchButton.click();

            //check on correct data login and password
            if (method.isElementPresentByXpath(".//*[@id='errorsTable']")) {
                LOG.info("Error on Login Page: " + driver.findElement(By.xpath(".//*[@id='errorsTable']")).getText());
            } else {
            }
        } catch (Exception e) {
            LOG.error("Exception during driver inialization", e);
        }

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #1 - check data on overview page
    public void testCaseOnOverviewPage() {

        overviewPageTest(Locators.LOCALE_RU);
        overviewPageTest(Locators.LOCALE_UA);
        overviewPageTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void overviewPageTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.verifyTitle(getCompositeMessage(Locators.TITLE_OVERVIEW_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_CORE_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_OVERVIEW_PAGE_ELEMENTS, locale));

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #2 - check data on summary page
    public void wirelessNumberSummaryPage() {

        wirelessNumberSummaryTest(Locators.LOCALE_RU);
        wirelessNumberSummaryTest(Locators.LOCALE_UA);
        wirelessNumberSummaryTest(Locators.LOCALE_US);

        checkTestFailed();

    }

    private void wirelessNumberSummaryTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[2]/ul/li/a"), "FTTB Cost");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_WIRELESS_NUMBER_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_AGREEMENT_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_AGREEMENT_TEXT_ELEMENTS, locale));

        downloadReport(Locators.ReportType.CSV, locale);
        downloadReport(Locators.ReportType.XML, locale);

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }




    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #3 - check data on account detailed traffic
    public void accountDetailedPage() {

        accountDetailedPageTest(Locators.LOCALE_RU);
        accountDetailedPageTest(Locators.LOCALE_UA);
        accountDetailedPageTest(Locators.LOCALE_US);

        checkTestFailed();

    }

    private void accountDetailedPageTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[2]/ul/li/a"), "FTTB Cost");
        method.clickOnElementBy(By.xpath(".//*[@id='mainContentTable']/tbody/tr/td[1]/ul/li[2]/a"), "FTTB account detailed traffic element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_WIRELESS_NUMBER_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_AGREEMENT_ELEMENTS, locale));

        downloadReport(Locators.ReportType.CSV, locale);
        method.checkWrongPageAndForward(getCompositeMessage(Locators.FTTB_PAGE_NO_DATA, locale));

        downloadReport(Locators.ReportType.XML, locale, false);
        method.checkWrongPageAndForward(getCompositeMessage(Locators.FTTB_PAGE_NO_DATA, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview Page");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #4 - check data on account detailed charge
    public void accountDetailedChargePage() {

        accountDetailedChargeTest(Locators.LOCALE_RU);
        accountDetailedChargeTest(Locators.LOCALE_UA);
        accountDetailedChargeTest(Locators.LOCALE_US);

        checkTestFailed();

    }

    private void accountDetailedChargeTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[2]/ul/li/a"), "FTTB Cost");
        method.clickOnElementBy(By.xpath(".//*[@id='mainContentTable']/tbody/tr/td[1]/ul/li[3]/a"), "FTTB account detailed charge element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_WIRELESS_NUMBER_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_AGREEMENT_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_ACCOUNT_DETAILED_TEXT_ELEMENTS, locale));

        downloadReport(Locators.ReportType.CSV, locale);
        downloadReport(Locators.ReportType.XML, locale);

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #5 - check data on unbilled usage page
    public void unbilledUsagePage() {

        unbilledUsageTest(Locators.LOCALE_RU);
        unbilledUsageTest(Locators.LOCALE_UA);
        unbilledUsageTest(Locators.LOCALE_US);

        checkTestFailed();

    }

    private void unbilledUsageTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[2]/ul/li/a"), "FTTB Cost");
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/ul/li[2]/a"), "FTTB unbilled usage element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_UNBILLED_USAGE_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_UNBILLED_USAGE_ELEMENTS, locale));

        downloadReport(Locators.ReportType.CSV, locale);
        method.checkWrongPageAndForward(getCompositeMessage(Locators.FTTB_PAGE_NO_DATA, locale));

        downloadReport(Locators.ReportType.XML, locale, false);
        method.checkWrongPageAndForward(getCompositeMessage(Locators.FTTB_PAGE_NO_DATA, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #6 - check data on reports page
    public void reportsBonusPage() {

        reportsBonusTest(Locators.LOCALE_RU);
        reportsBonusTest(Locators.LOCALE_UA);
        reportsBonusTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void reportsBonusTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[2]/ul/li/a"), "FTTB Cost");
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/ul/li[3]/a"), "FTTB reports bonus element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_REPORTS_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_UNBILLED_USAGE_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_REPORTS_BONUS_TEXT_ELEMENTS, locale));

        downloadReport(Locators.ReportType.CSV, locale);
        downloadReport(Locators.ReportType.XML, locale);

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #7 - check data on profile page
    public void profileShowDoPage() {

        profileShowDoTest(Locators.LOCALE_RU);
        profileShowDoTest(Locators.LOCALE_UA);
        profileShowDoTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void profileShowDoTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[3]/ul/li/a"), "FTTB profile element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_PROFILE_SHOW_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_PROFILE_SHOW_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_PROFILE_SHOW_TEXT_ELEMENTS, locale));

        //edit personal data on profile page
        RemoteWebDriver driver = getWebDriver();

        String[] editButtonTag = getCompositeMessage(Locators.GENERAL_EDIT_BUTTON, locale);


        if (method.isElementPresentByXpath(editButtonTag[0])) {
            method.clickOnElementBy(By.xpath(editButtonTag[0]), editButtonTag[1]);

            method.fillTextField("./*//*[@id='firstName_field']", "TestName");
            method.fillTextField("./*//*[@id='lastName_field']", "TestSubname");
            method.fillTextField("./*//*[@id='email_field']", "test@test.test");

            if (method.isElementPresentByXpath("./*//*[@id='saveBtn']")) {
                method.clickOnElementBy(By.xpath("./*//*[@id='saveBtn']"), "FTTB save button");

                if (method.isElementPresentByXpath(Locators.greenMessage)) {
                    LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                    method.takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                    LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                    method.takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                } else {
                    LOG.info("No message");
                    method.takeScreenshot("No message");
                }
            } else {
                LOG.info("Save button absence");
            }
        } else {
            LOG.info("Element absence");
        }

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #8 - check data on profile notifications page
    public void profileNotificationPage() {

        profileNotificationTest(Locators.LOCALE_RU);
        profileNotificationTest(Locators.LOCALE_UA);
        profileNotificationTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void profileNotificationTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[3]/ul/li/a"), "FTTB profile element");
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/ul/li[2]/a"), "FTTB profile notifications element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_PROFILE_NOTIFICATION_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_PROFILE_SHOW_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_PROFILE_NOTIFICATION_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #9 - check data on profile personal address book page
    public void profilePersonaleAddressBookPage() {

        profilePersonaleAddressBookTest(Locators.LOCALE_RU);
        profilePersonaleAddressBookTest(Locators.LOCALE_UA);
        profilePersonaleAddressBookTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void profilePersonaleAddressBookTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[3]/ul/li/a"), "FTTB profile element");
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/ul/li[3]/a"), "FTTB personal address book element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_PROFILE_ADDRESS_BOOK_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_PROFILE_SHOW_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_PROFILE_ADDRESS_BOOK_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #10 - check data on payment page
    public void paymentActivityPage() {

        paymentActivityTest(Locators.LOCALE_RU);
        paymentActivityTest(Locators.LOCALE_UA);
        paymentActivityTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void paymentActivityTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[4]/ul/li/a"), "FTTB payment activity element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_PAYMENT_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.TITLE_OVERVIEW_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_PAYMENT_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #11 - check data on feature page
    public void tsmOverviewPage() {

        tsmOverviewTest(Locators.LOCALE_RU);
        tsmOverviewTest(Locators.LOCALE_UA);
        tsmOverviewTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void tsmOverviewTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[5]/ul/li/a"), "FTTB feature overview elements");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_TSM_OVERVIEW_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_TSM_OVERVIEW_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_TSM_OVERVIEW_TEXT_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #12 - check data on archive orders page
    public void tsmArchiveOrdersPage() {

        tsmArchiveOrdersTest(Locators.LOCALE_RU);
        tsmArchiveOrdersTest(Locators.LOCALE_UA);
        tsmArchiveOrdersTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void tsmArchiveOrdersTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[5]/ul/li/a"), "FTTB feature overview elements");
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/ul/li[2]/a"), "FTTB archive orders element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_TSM_ARCHIVE_ORDERS_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_TSM_OVERVIEW_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_ARCHIVE_ORDERS_TEXT_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #13 - check data on providers page
    public void providersRegPage() {

        providersRegTest(Locators.LOCALE_RU);
        providersRegTest(Locators.LOCALE_UA);
        providersRegTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void providersRegTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[6]/ul/li/b"), "FTTB providers element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_PROVIDERS_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.TITLE_OVERVIEW_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_PROVIDERS_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #14 - check data on help inside (faq) page
    public void helpInsidePage() {

        helpInsidePage(Locators.LOCALE_RU);
        helpInsidePage(Locators.LOCALE_UA);
        helpInsidePage(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void helpInsidePage(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[7]/ul/li/a"), "FTTB help inside element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_HELP_INSIDE_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_HELP_INSIDE_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_HELP_INSIDE_TEXT_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #15 - check data on user manual page
    public void userManualPage() {

        userManualTest(Locators.LOCALE_RU);
        userManualTest(Locators.LOCALE_UA);
        userManualTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void userManualTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[7]/ul/li/a"), "FTTB help inside element");
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/ul/li[2]/a"), "FTTB user manual element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_USER_MANUAL_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_HELP_INSIDE_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #16 - check data on feedback page
    public void sendQuestionPage() {

        sendQuestionTest(Locators.LOCALE_RU);
        sendQuestionTest(Locators.LOCALE_UA);
        sendQuestionTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void sendQuestionTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[7]/ul/li/a"), "FTTB help inside element");
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/ul/li[3]/a"), "FTTB feedback page element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_FEEDBACK_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_HELP_INSIDE_ELEMENTS, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_FEEDBACK_TEXT_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #17 - check data on feedback page
    public void termsConditionsHIPage() {

    }

    @Test(groups = {"internetExplorer", "chrome", "fireFox", "RU", "UA", "US"})
    //Test #18 - check data on sitemap show page
    public void sitemapShowPage() {

        sitemapShowTest(Locators.LOCALE_RU);
        sitemapShowTest(Locators.LOCALE_UA);
        sitemapShowTest(Locators.LOCALE_US);

        checkTestFailed();
    }

    private void sitemapShowTest(Locale locale) {

        verifyTimeout(Locators.VERIFY_TIMEOUT_PAGE, locale);

        method.switchLocalisation(getCompositeMessage(Locators.LOCALE_XPATH_MK_KEY, locale));
        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[8]/ul/li/b"), "FTTB sitemap element");

        method.verifyTitle(getCompositeMessage(Locators.TITLE_SITEMAP_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.TITLE_OVERVIEW_FTTB, locale));
        method.verifyTextOnPage(getCompositeMessages(Locators.FTTB_PAGE_SITEMAP_TEXT_ELEMENTS, locale));

        method.clickOnElementBy(By.xpath(".//*[@id='navigation']/td[1]/table/tbody/tr/td/table/tbody/tr/td[1]/ul/li/a"), "FTTB Overview");

    }
}
