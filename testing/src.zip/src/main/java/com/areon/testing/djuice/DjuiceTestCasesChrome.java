package com.areon.testing.djuice;

import com.areon.testing.common.Data;
import com.areon.testing.common.Locators;
import com.areon.testing.common.old.ChromeCoreTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;

public class DjuiceTestCasesChrome extends ChromeCoreTest {

    private static Logger LOG = LoggerFactory.getLogger(DjuiceTestCasesChrome.class);

    /*@BeforeClass
    public void initDriver() {
        LOG.info("initDriver start");

        RemoteWebDriver driver = getWebDriver();

        try {
            //go to test page
            driver.get(Data.BASE_URL);

*//*            try {
//                driver.findElement(By.xpath(Locators.localRuXpath)).click();
            } catch (Exception e) {
            }*//*

            //login on system
            WebElement searchField = driver.findElement(By.xpath(Locators.loginFormXpath));
            searchField.clear();
            searchField.sendKeys(Locators.getApplicationProperty(Locators.DJUICE_LOGIN));
            WebElement searchField2 = driver.findElement(By.name(Locators.passwordFormName));
            searchField2.clear();
            searchField2.sendKeys(Locators.getApplicationProperty(Locators.DJUICE_PASSWORD));
            WebElement searchButton = driver.findElement(By.name(Locators.submitButtonName));
            searchButton.click();

            if (method.isElementPresentByXpath("./[@id='errorsTable']")) {
                LOG.info("Error on Login Page: " + driver.findElement(By.xpath("./[@id='errorsTable']")).getText());
            } else {
            }
        } catch (Exception e) {
            LOG.error("Exception during driver inialization", e);
        }

    }*/

    /*
    //verifying on timeout session
    public void verifyTimeout() {

        if (method.isElementPresentByText(getMessage(Data.VERIFY_TIMEOUT_PAGE,LOCALE_RU))) {
            LOG.info("Start browser correct");
        } else {
            LOG.info("Start browser incorrect");
            Assert.fail("Timeout exception");

        }
    }
    */
/*
    @Test(priority = 1)
    //test case verify UI on overview page
    public void testCaseOnOverviewPage() {

        //verifyTimeout();
        boolean testPassed = true;
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_OVERVIEW_DJUICE, Locators.LOCALE_RU));
        testPassed &= method.isTextOnPageCorrect(Data.linksOverviewPageRu);
        method.verifyTextOnPage(Data.textOverviewPageRu);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_OVERVIEW_DJUICE, Locators.LOCALE_UA));
        //method.verifyTextOnPage(Data.linksOverviewPageUa);
        testPassed &= method.isTextOnPageCorrect(Data.linksOverviewPageUa);
        method.verifyTextOnPage(Data.textOverviewPageUa);

        method.takeScreenshot("testCaseonOverviewPage");

        Assert.assertTrue("Test failed", Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 2)
    public void testCaseonCostPageSummary() {

        boolean testPassed = true;

        method.switchLocalisation(Locators.localRuXpath);
        driver.findElement(By.xpath("./*//*[@id='2']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/b2c/view/wireless_number_summary.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(getMessage(Data.TITLE_COST_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksCostPageRu);
        method.verifyTextOnPage(Data.TEXT_DJUICE_COST_SUMMARY_PAGE_RU);
        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_COST_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksCostPageUa);
        method.verifyTextOnPage(Data.TEXT_DJUICE_COST_SUMMARY_PAGE_UA);

        method.takeScreenshot("testCaseonCostPageSummary");

        Assert.assertTrue("Test failed", Boolean.TRUE.equals(testPassed));
    }

    @Test(priority = 3)
    public void testCaseonDetailedUsagePage() {

        boolean testPassed = true;

        method.switchLocalisation(Locators.localRuXpath);

        driver.findElement(By.xpath("./*//*[@id='2_2']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/b2c/view/detailed_usage.do");
        new WebDriverWait(driver, 10);

        method.verifyTitle(getMessage(Data.TITLE_DETAIL_USAGE_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksCostPageRu);
        method.verifyTextOnPage(Data.TEXT_DJUICE_DETAIL_USAGE_PAGE_RU);
        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_DETAIL_USAGE_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksCostPageUa);
        method.verifyTextOnPage(Data.TEXT_DJUICE_DETAIL_USAGE_PAGE_UA);

        method.takeScreenshot("testCaseonDetailedUsagePage");

        Assert.assertTrue("Test failed", Boolean.TRUE.equals(testPassed));
    }

    @Test(priority = 4)
    public void testCaseonUnbilledUsagePage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='2_3']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/view/unbilled_usage.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_UNBILL_USAGE_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksCostPageRu);
        method.verifyTextOnPage(Data.TEXT_DJUICE_UNBILLED_USAGE_RU);

        method.getReport(Locators.receiveButtonRu, Locators.confirmButtonRu);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_UNBILL_USAGE_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksCostPageUa);
        method.verifyTextOnPage(Data.TEXT_DJUICE_UNBILLED_USAGE_UA);

        new WebDriverWait(driver, 10);

        method.getReport(Locators.receiveButtonUa, Locators.confirmButtonUa);
        method.takeScreenshot("testCaseonUnbilledUsagePage");

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 5)
    public void testCaseonWirelessNumberPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='2_4']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/view/wireless_number_chrgs.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_WIRELESS_NUMBER_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksCostPageRu);
        method.verifyTextOnPage(Data.TEXT_DJUICE_WIRELESS_NUMBER_RU);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_WIRELESS_NUMBER_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksCostPageUa);
        method.verifyTextOnPage(Data.TEXT_DJUICE_WIRELESS_NUMBER_UA);

        method.takeScreenshot("testCaseonWirelessNumberPage");

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }


    @Test(priority = 6)
    public void testCaseonReportsPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='2_5']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/b2c/view/reports.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_REPORTS_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksCostPageRu);
        method.verifyTextOnPage(Data.TEXT_DJUICE_REPORTS_RU);

        method.generateReport();
        method.printReport();

        if (method.isElementPresentByText(Locators.downloadOnFileLink)) {
            method.clickOnlinkText(Locators.downloadOnFileLink);
            method.downloadReport("CSV");
            method.downloadReport("XML");
        } else {
            LOG.info("Link download file absence");
        }

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_REPORTS_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksCostPageUa);
        method.verifyTextOnPage(Data.TEXT_DJUICE_REPORTS_UA);

        method.takeScreenshot("testCaseonReportsPage");

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }


    @Test(priority = 7)
    public void testCaseonPersonalProfilePage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='3']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/b2c/profile/personal_profile.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_PERSONAL_PROFILE_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksPersonalProfileRu);
        method.verifyTextOnPage(Data.TEXT_DJUICE_PERSONAL_PROFILE_RU);

        if (method.isElementPresentByXpath(Locators.GENERAL_EDIT_BUTTON)) {
            method.clickOnElementXpath(Locators.GENERAL_EDIT_BUTTON);

            method.fillTextField("./*//*[@id='firstName_field']", "TestName");
            method.fillTextField("./*//*[@id='lastName_field']", "TestSubname");
            method.fillTextField("./*//*[@id='email_field']", "test@test.test");

            if (method.isElementPresentByXpath("./*//*[@id='saveBtn']")) {
                method.clickOnElementXpath("./*//*[@id='saveBtn']");

                if (method.isElementPresentByXpath(Locators.greenMessage)) {
                    LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                    method.takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                    LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                    method.takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                } else {
                    LOG.info("No message");
                    method.takeScreenshot("No message");
                }
            } else {
                LOG.info("Save button absence");
            }
        } else {
            LOG.info("Element absence");
        }

        method.clickOnlinkText(Data.linkPersonalProfileRU);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_PERSONAL_PROFILE_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksPersonalProfileUa);
        method.verifyTextOnPage(Data.TEXT_DJUICE_PERSONAL_PROFILE_UA);

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }


    @Test(priority = 8)
    public void testCaseonNotificationsPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='3_3']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/profile/notifications.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_NOTIFICATIONS_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksPersonalProfileRu);
        method.verifyTextOnPage(Data.textNotificationsRu);

        if (method.isElementPresentByXpath(Locators.GENERAL_SAVE_BUTTON)) {
            LOG.info("Save button present");
            if (driver.findElement(By.xpath(Locators.GENERAL_SAVE_BUTTON)).isDisplayed()) {
                LOG.info("Save button isDisplayed");
            } else {
                LOG.info("Save button not Displayed");
            }
        } else {
            LOG.info("Save button absence");
            method.takeScreenshot("Save button absence");
        }

        method.verifySizeElements("//input[@type='checkbox']", 6, "checkbox");

        List<WebElement> list = driver.findElements(By.xpath("//input[@type='checkbox']"));
        for (WebElement item : list) {
            if (item.isDisplayed()) {
                item.click();
                LOG.info("Checkbox is clicable");
            } else {
                LOG.info("Checkbox " + item + " no active");
            }
        }

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_NOTIFICATIONS_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksPersonalProfileUa);
        method.verifyTextOnPage(Data.TEXT_DJUICE_NOTIFICATIONS_UA);

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }


    @Test(priority = 9)
    public void testCaseonPersonalAddressBookPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='3_4']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/profile/personal_address_book.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);

        Integer t1 = driver.findElements(By.xpath("//input[@type='checkbox']")).size();
        LOG.info("intValue" + t1.intValue());

        driver.get("https://my.djuice.ua/tbmb/addressbook/pab-addnew/show.do");
        new WebDriverWait(driver, 5);

        String dateFormat = "MM.dd_h.mm.ss";
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat SDF = new SimpleDateFormat(dateFormat);
        String randomNumber = SDF.format(cal.getTime());

        method.fillTextField("./*//*[@name='phoneNumber']", randomNumber);
        method.fillTextField("./*//*[@name='alias']", randomNumber);
        method.fillTextField("./*//*[@name='name']", randomNumber);

        if (method.isElementPresentByXpath(Locators.GENERAL_SAVE_BUTTON)) {
            method.clickOnElementXpath(Locators.GENERAL_SAVE_BUTTON);

            if (method.isElementPresentByXpath(Locators.greenMessage)) {
                LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                method.takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
            } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                method.takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
            } else {
                LOG.info("No message");
                method.takeScreenshot("No message");
            }
        } else {
            LOG.info("SaveButton absence");
        }

        //method.clickOnlinkText(Data.linkAddressBookRU);
        driver.get("https://my.djuice.ua/tbmb/profile/personal_address_book.do");

        List<WebElement> list = driver.findElements(By.xpath("//input[@type='checkbox']"));
        for (WebElement x : list) {
            if (x.isDisplayed()) {
                x.click();
                if (method.isElementPresentByXpath(Locators.deleteButtonRu)) {
                    method.clickOnElementXpath(Locators.deleteButtonRu);
                    if (method.isElementPresentByXpath("./*//*[@type='submit']")) {
                        method.clickOnElementXpath("./*//*[@type='submit']");
                        LOG.info("All contacts delete");
                        return;
                    } else {
                        LOG.info("SubmitButton not Displayed");
                        return;
                    }
                } else {
                    LOG.info("DeleteButton not Displayed");
                    return;
                }
            } else {
                LOG.info("Checkbox not Displayed");
                return;
            }
        }

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 10)
    public void testCaseonPaymentPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='4']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/payment/activity/show.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_PAYMENT_ACTIVITY_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksPaymentRu);
        method.verifyTextOnPage(Data.TEXT_DJUICE_PAYMENT_RU);

        method.generateReport();

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_PAYMENT_ACTIVITY_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksPaymentUa);
        method.verifyTextOnPage(Data.TEXT_DJUICE_PAYMENT_UA);

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 11)
    public void testCaseonFeatureOverviewPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='5']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/tsm/overview.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_FEATURE_OVERVIEW_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksFeatureRu);
        method.verifyTextOnPage(Data.TEXT_DJUICE_FEATURE_OVERVIEW_RU);

        method.takeScreenshot("Feature page RU");

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_FEATURE_OVERVIEW_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksFeatureUa);
        method.verifyTextOnPage(Data.TEXT_DJUICE_FEATURE_OVERVIEW_UA);

        method.takeScreenshot("Feature page UA");

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }


    @Test(priority = 12)
    public void testCaseonArchiveOrdersPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='5_3']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/tsm/archiveOrders.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_ARCHIVE_ORDERS_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksFeatureRu);

        method.takeScreenshot("Archive Orders page RU");
        method.changeFeature();

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_ARCHIVE_ORDERS_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksFeatureUa);

        method.takeScreenshot("Archive Orders page UA");

        Assert.assertTrue("Test failed", Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 13)
    public void testCaseonMobileCommunicationPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='9']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/involvements/documents/mobileCommunicationSA_dj/show.do");
        new WebDriverWait(driver, 10);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_COMMUNICATION_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksCommunicationRu);

        method.takeScreenshot("Communication page RU");

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_COMMUNICATION_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksCommunicationUa);

        method.takeScreenshot("Communication page UA");

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }


    @Test(priority = 14)
    public void testCaseonAppFormPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='9_2']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/involvements/documents/appForm_dj/show.do");
        new WebDriverWait(driver, 5);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_APPLICATION_FORM_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksAppFormRu);

        method.takeScreenshot("Application form page RU");

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_APPLICATION_FORM_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksAppFormUa);

        method.takeScreenshot("Application form UA");

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 15)
    public void testCaseonMoneyTransferPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='6']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/moneyTransfer/show.do");
        new WebDriverWait(driver, 5);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_MONEY_TRANSFER_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksMoneyTransferRu);

        method.fillTextField("./*//*[@id='phone']", "971202020");
        method.fillTextField("./*//*[@id='transferAmount']", "1");

        for (int i = 0; i < 3; i++) {
            if (method.isElementPresentByXpath(Locators.submitButton)) {
                driver.findElement(By.xpath(Locators.submitButton)).click();
                continue;
            } else if (method.isElementPresentByXpath(Locators.greenMessage)) {
                LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                method.takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                break;
            } else if (method.isElementPresentByXpath(Locators.errorMessage)) {
                LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                method.takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                break;
            } else {
                LOG.info("Nothing");
                break;
            }
        }

        driver.get("https://my.djuice.ua/tbmb/moneyTransfer/show.do");

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_MONEY_TRANSFER_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksMoneyTransferUa);

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 16)
    public void testCaseonProvidersPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='6_2']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/help/providers_reg.do");
        new WebDriverWait(driver, 5);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_MONEY_PROVIDERS_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksMoneyTransferRu);

        method.takeScreenshot("Money providers page RU");

        method.verifyElementValue("./*//*[@href='/tbmb/balance_recharge.do?provider=0']", "Портмоне.сом", "Provider |");
        method.verifyElementValue("./*//*[@href='/tbmb/balance_recharge.do?provider=1']", "EasyPay", "Provider |");
        method.verifyElementValue("./*//*[@href='/tbmb/balance_recharge.do?provider=2']", "Приватбанк", "Provider |");

        driver.get("https://my.djuice.ua/tbmb/help/providers_reg.do");
        new WebDriverWait(driver, 5);

        method.switchLocalisation(Locators.localUaXpath);
        method.verifyTitle(getMessage(Data.TITLE_MONEY_PROVIDERS_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksMoneyTransferUa);
        method.takeScreenshot("Money providers page UA");

        Assert.assertTrue("Test failed", Boolean.TRUE.equals(testPassed));
    }


    @Test(priority = 17)
    public void testCaseonSendQuestionPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='7']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/help_inside/sendQuestion/show.do");
        new WebDriverWait(driver, 5);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_SEND_QUESTION_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linkssendQuestionRu);

        method.takeScreenshot("Send question page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);
        method.verifyTitle(getMessage(Data.TITLE_SEND_QUESTION_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linkssendQuestionUa);

        method.takeScreenshot("Send question page UA");

        Assert.assertTrue("Test failed", Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 18)
    public void testCaseonFaqPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='7_2']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/help_inside/faq.do");
        new WebDriverWait(driver, 5);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_FAQ_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linkssendQuestionRu);
        method.verifyTextOnPage(Data.linksFaqRu);

        method.takeScreenshot("Faq page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);
        method.verifyTitle(getMessage(Data.TITLE_FAQ_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linkssendQuestionUa);
        method.verifyTextOnPage(Data.linksFaqUa);

        method.takeScreenshot("Faq page UA");

        Assert.assertTrue("Test failed", Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 19)
    public void testCaseonUserManualPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='7_4']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/help_inside/userManual.do");
        new WebDriverWait(driver, 5);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_USER_MANUAL_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linkssendQuestionRu);

        method.takeScreenshot("UserManual page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);
        method.verifyTitle(getMessage(Data.TITLE_USER_MANUAL_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linkssendQuestionUa);

        method.takeScreenshot("UserManual page UA");

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 20)
    public void testCaseonTermsConditionsPage() {

        boolean testPassed = true;

        driver.findElement(By.xpath("./*//*[@id='7_5']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/help_inside/termsConditions.do");
        new WebDriverWait(driver, 5);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_TERMS_CONDITIONS_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linkssendQuestionRu);

        method.takeScreenshot("Terms Conditions page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);
        method.verifyTitle(getMessage(Data.TITLE_TERMS_CONDITIONS_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linkssendQuestionUa);

        method.takeScreenshot("Terms Conditions page UA");

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }

    @Test(priority = 21)
    public void testCaseonSitemapPage() {

        boolean testPassed = true;


        driver.findElement(By.xpath("./*//*[@id='8']/a")).click();
        //driver.get(Data.BASE_URL + "/tbmb/sitemap/show.do");
        new WebDriverWait(driver, 5);

        method.switchLocalisation(Locators.localRuXpath);
        method.verifyTitle(getMessage(Data.TITLE_SITEMAP_DJUICE, Locators.LOCALE_RU));
        method.verifyTextOnPage(Data.linksSitemapRu);

        method.takeScreenshot("Sitemap page RU");

        method.switchLocalisation(Locators.localUaXpath);
        new WebDriverWait(driver, 5);

        method.verifyTitle(getMessage(Data.TITLE_SITEMAP_DJUICE, Locators.LOCALE_UA));
        method.verifyTextOnPage(Data.linksSitemapUa);
        method.takeScreenshot("Sitemap page UA");

        Assert.assertTrue("Test failed",Boolean.TRUE.equals(testPassed));

    }*/
}
