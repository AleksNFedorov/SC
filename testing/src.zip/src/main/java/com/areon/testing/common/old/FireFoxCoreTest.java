package com.areon.testing.common.old;

import com.areon.testing.common.CoreTest;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 11/12/13
 * Time: 5:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class FireFoxCoreTest extends CoreTest {

/*
    @Override
    protected FirefoxDriver createBrowserDriver() throws IOException {

        String systemSpecificFireFoxInstallation = Locators.getApplicationProperty(PATH_TO_FIRE_FOX_PROPERTY);
        String systemSpecificFireFoxDownloadFolder = Locators.getApplicationProperty(PATH_TO_FIRE_FOX_DOWNLOAD_FOLDER_PROPERTY);

        FirefoxProfile profile = new FirefoxProfile();
        profile.setPreference("browser.download.folderList", 2);
        profile.setPreference("browser.download.manager.showWhenStarting", false);
        profile.setPreference("browser.download.dir", systemSpecificFireFoxDownloadFolder);
        profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "text/csv, text/xml");

        FirefoxDriver driver = new FirefoxDriver(new FirefoxBinary(new File(systemSpecificFireFoxInstallation)), profile);

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        driver.manage().window().maximize();
        return driver;
    }

    @Override
    protected UsageMethods<FirefoxDriver> createUsageMethods(FirefoxDriver driver) {
        return new UsageMethods<FirefoxDriver>(driver);
    }
*/

}
