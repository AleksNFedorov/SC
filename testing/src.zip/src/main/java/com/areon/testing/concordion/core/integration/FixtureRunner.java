package com.areon.testing.concordion.core.integration;

import org.concordion.api.ResultSummary;
import org.concordion.api.SpecificationLocator;
import org.concordion.internal.ClassNameBasedSpecificationLocator;
import org.concordion.internal.ConcordionBuilder;
import org.concordion.internal.extension.FixtureExtensionLoader;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: Fedorovaleks
 * Date: 01.01.14
 * Time: 13:29
 * To change this template use File | Settings | File Templates.
 */
public class FixtureRunner {

    private FixtureExtensionLoader fixtureExtensionLoader = new FixtureExtensionLoader();

    private SpecificationLocator specificationLocator = new ClassNameBasedSpecificationLocator();

    public ResultSummary run(final Object fixture) throws IOException {
        ConcordionBuilder concordionBuilder = createBuilder(fixture);
        fixtureExtensionLoader.addExtensions(fixture, concordionBuilder);
        ResultSummary resultSummary = concordionBuilder.build().process(fixture);
        resultSummary.print(System.out, fixture);
        resultSummary.assertIsSatisfied(fixture);
        return resultSummary;
    }

    protected ConcordionBuilder createBuilder(final Object fixture) {
        ConcordionBuilder concordionBuilder = new ConcordionBuilder().withFixture(fixture);
        concordionBuilder = concordionBuilder.withSpecificationLocator(specificationLocator);
        return concordionBuilder;
    }

    public void setSpecificationLocator(SpecificationLocator specificationLocator) {
        this.specificationLocator = specificationLocator;
    }
}
