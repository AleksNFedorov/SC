package com.areon.testing.common.old;

import com.areon.testing.common.Locators;
import com.areon.testing.common.context.TestContextService;
import com.google.common.io.Files;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Reporter;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Deprecated
public class UsageMethods {

   private static Logger LOG = LoggerFactory.getLogger(UsageMethods.class);

    protected TestContextService testContextService;

    private RemoteWebDriver driver;


    public UsageMethods(TestContextService service) {
        this.testContextService = service;
        this.driver = service.getDriver();
    }

    public boolean isElementPresentByXpath(String xpathLocator) {
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        List<WebElement> list = driver.findElementsByXPath(xpathLocator);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        if (list.size() == 0) {
            return false;
        } else {
            return list.get(0).isDisplayed();
        }
    }

    public boolean isElementPresentByText(String textToLookUp) {
        driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        List<WebElement> list = driver.findElementsByLinkText(textToLookUp);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        if (list.size() == 0) {
            return false;
        } else {
            return list.get(0).isDisplayed();
        }
    }

    public void checkWrongPageAndForward(String[] checkparams) {

    }

    public void takeScreenshot(String textNearTheScreen) {

        File screenshotTempFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            File reportScreenShotFile = createScreenShotFile(new SimpleDateFormat(Locators.TIME_FORMAT).format(Calendar.getInstance().getTime()), Locators.ResultType.Fail);
            Files.move(screenshotTempFile, reportScreenShotFile);
            Reporter.log(textNearTheScreen + " <a href='" + reportScreenShotFile.getAbsolutePath() + "'>" + " screenshot</a>");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    public void takeScreenshot(String textNearTheScreen, String screenShotDescription, Locators.ResultType resultType) {

        File screenshotTempFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            File reportScreenShotFile = createScreenShotFile(screenShotDescription, resultType);
            Files.move(screenshotTempFile, reportScreenShotFile);
            Reporter.log(textNearTheScreen + " <a href='" + reportScreenShotFile.getAbsolutePath() + "'>" + " screenshot</a>");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private File createScreenShotFile(String screenShotDescription, Locators.ResultType resultType) throws IOException {
        File fileFolder = null;
//        File fileFolder = Locators.getOutputFolder(resultType);
        String fileName = screenShotDescription.replace(" ", "_") + ".png";
        File screenSotFile = new File(fileFolder, fileName);
        if (screenSotFile.exists())
            if (!screenSotFile.delete())
                throw new IOException("File with same name [" + fileName + "] already exist, can`t delete");
        return screenSotFile;
    }

    public void switchLocalisation(String[] locatorLocalisation) {
/*
        try {
            new WebDriverWait(driver, 5);
            driver.findElement(By.xpath(locatorLocalisation)).click();
        } catch (Exception e) {
        }
*/
    }

    public void verifyTitle(String[] title) {
/*
        try {
            new WebDriverWait(driver, 5);
            if (driver.getTitle().contains(title)) {
                LOG.info("Correct title!");
            } else {
                LOG.info("Title: " + driver.getTitle());
            }
        } catch (Exception e) {
        }
*/
    }

    public void onFail(String failMessage, String failDescription) {
        throw new UnsupportedOperationException();
    }


        public void verifyTextOnPage(String[][] dataToCheck) {
        boolean textVerificationFailed = false;
        try {
            for (String[] checkDataPair : dataToCheck) {
                String textDataToCheck = checkDataPair[Locators.TestDataContainer.TestContent.ordinal()];
                String textDataToCheckDescription = checkDataPair[Locators.TestDataContainer.TestContentDescription.ordinal()];

                if ((driver.findElement(By.xpath(Locators.pageXpath))).getText().contains(textDataToCheck)) {
                } else {
                    LOG.info("Text absence: description [{}], text [{}]", textDataToCheckDescription, textDataToCheck);
                    Reporter.log("Text absence: ["+textDataToCheckDescription+"], test ["+textDataToCheck+"]");
                    takeScreenshot("Text absence: " + textDataToCheck, textDataToCheckDescription, Locators.ResultType.Fail);
                    textVerificationFailed = true;
                }
            }
        } catch (Exception e) {
            LOG.error("Exception during text verification ", e);
            Reporter.log("Error during text verification ["+e.getMessage()+"");
            textVerificationFailed = true;
        }
    }

    public void verifyTextOnPage(String text[]) {
        try {
            for (String x : text) {
                if ((driver.findElement(By.xpath(Locators.pageXpath))).getText().contains(x)) {
                } else {
                    LOG.info("Text absence: " + x);
                    takeScreenshot("Text absence: " + x);
                }
            }
        } catch (Exception e) {
            LOG.error("Error during text verification ", e);
        }
    }

    public void clickOnlinkText(String locator) {
        try {
            new WebDriverWait(driver, 10);
            if (isElementPresentByText(locator)) {
                driver.findElement(By.linkText(locator)).click();
            } else {
                LOG.info("Link " + locator + " absence");
            }
        } catch (Exception e) {
        }
    }

    public void clickOnElementBy(By by, String modifier) {
/*        try {
            new WebDriverWait(driver, 10);
            if (isElementPresentByXpath(locator)) {
                driver.findElement(By.xpath(locator)).click();
            } else {
                LOG.info("Link " + locator + " absence");
            }
        } catch (Exception e) {
        }*/
    }

    public void generateReport() {
        try {
            new Select(driver.findElement(By.xpath(Locators.selectReportPeriod))).selectByIndex(1);
            if (isElementPresentByXpath(Locators.generateReportButton)) {
                driver.findElement(By.xpath(Locators.generateReportButton)).click();
                LOG.info("Success report!");
                takeScreenshot("Success report: ");
            } else {
                LOG.info("Button generateReport absence!");
                takeScreenshot("Button generateReport absence!: ");
            }
        } catch (Exception e) {
        }
    }

    public void downloadReport(String format, String downloadButtonXPath, String downloadButtonModifier) {
/*        try {
            new WebDriverWait(driver, 15).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Locators.formSelectDownloadFile)));

            new Select(driver.findElement(By.xpath(Locators.formSelectDownloadFile))).selectByVisibleText(format);
            driver.findElement(By.xpath(Locators.buttonDownload)).click();

            if (driver.getCurrentUrl().contains(Data.BASE_URL + "/tbmb/view/download.do")) {
                LOG.info("Empty report");
                takeScreenshot("Empty report: ");
                driver.navigate().back();
            } else {
                LOG.info("Success report of " + format + " format!");
            }
        } catch (Exception e) {
            LOG.info("Error: " + e);
        }*/
    }

    public void printReport() {
        try {
            if (isElementPresentByText(Locators.printLink)) {
                String originalWindow = driver.getWindowHandle();
                final Set<String> oldWindowsSet = driver.getWindowHandles();
                driver.findElement(By.linkText(Locators.printLink)).click();
                String newWindow = (new WebDriverWait(driver, 20))
                        .until(new ExpectedCondition<String>() {
                            public String apply(WebDriver driverCH) {
                                Set<String> newWindowsSet = driverCH.getWindowHandles();
                                newWindowsSet.removeAll(oldWindowsSet);
                                return newWindowsSet.size() > 0 ?
                                        newWindowsSet.iterator().next() : null;
                            }
                        }
                        );
                new WebDriverWait(driver, 10);
                driver.switchTo().window(newWindow);
                LOG.info("PrintReport!");
                takeScreenshot("Page PrintReport!");
                driver.close();
                driver.switchTo().window(originalWindow);
            }
        } catch (Exception e) {
            LOG.info("Error: " + e);
        }
    }

    public void getReport(String receiveButton, String confirmButton) {
        try {
            new Select(driver.findElement(By.xpath(Locators.selectReportPeriod))).selectByIndex(0);
            driver.findElement(By.xpath(Locators.generateReportButton)).click();
            if (isElementPresentByXpath(receiveButton)) {
                driver.findElement(By.xpath(receiveButton)).click();
                if (isElementPresentByXpath(confirmButton)) {
                    driver.findElement(By.xpath(confirmButton)).click();
                    if (isElementPresentByXpath(Locators.greenMessage)) {
                        LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                        takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                    } else if (isElementPresentByXpath(Locators.errorMessage)) {
                        LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                        takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                    } else {
                        LOG.info("Error getReport");
                        takeScreenshot("Error getReport");
                    }
                } else {
                    LOG.info("ConfirmButton abcense");
                }
            } else {
                LOG.info("ReceiveButton abcense");
            }
        } catch (Exception e) {
            LOG.info("GetReport ERROR: " + e);
        }
    }

    public void fillTextField(String locator, String value) {
        try {
            new WebDriverWait(driver, 5);
            if (isElementPresentByXpath(locator)) {
                driver.findElement(By.xpath(locator)).clear();
                driver.findElement(By.xpath(locator)).sendKeys(value);
            } else {
                LOG.info("Element " + locator + " absence");
            }
        } catch (Exception e) {
        }
    }

    public void verifySizeElements(String locator, Integer size, String nameElement) {
        Integer t1 = driver.findElements(By.xpath(locator)).size();
        if (t1.equals(size)) {
            LOG.info("Success size element: " + nameElement);
        } else {
            LOG.info("Failure size element " + locator + " is: " + nameElement);
        }
    }

    public void verifyElementValue(String xpathLocator, String elementValue, String textLog) {
        try {
            if (driver.findElement(By.xpath(xpathLocator)).getText().contains(elementValue)) {
                LOG.info(textLog + elementValue + "| present on page");
            } else {
                LOG.info("Provider |" + elementValue + "| abcense on page");
            }
        } catch (Exception e) {
            LOG.info("ERROR on verifyElementValue: " + e);
        }
    }

    public void changeTariffPlan() {
        try {
            driver.findElement(By.xpath(".//*[@href='/tbmb/tsm/chg_rate_plan/show.do']")).click();

            WebElement selectElement = driver.findElement(By.xpath(".//*[@id='selPkgId']"));
            Select select = new Select(selectElement);
            select.selectByVisibleText("Удобный");

            driver.findElement(By.xpath(".//*[@value='Продолжить']")).click();

            if (isElementPresentByXpath(".//*[@value='Подать заявку']")) {
                driver.findElement(By.xpath(".//*[@value='Подать заявку']")).click();

                if (isElementPresentByXpath(Locators.greenMessage)) {
                    LOG.info("Success message is present at changeTariffPlan(): " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                    takeScreenshot("Success message is present at changeTariffPlan(): " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                }
            } else if (isElementPresentByXpath(Locators.errorMessage)) {
                LOG.info("ErrorMessage message is present at changeTariffPlan(): " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                takeScreenshot("ErrorMessage message is present at changeTariffPlan(): " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
            }
        } catch (Exception e) {
            LOG.info("ERROR on changeSettingFeature(): " + e);
        }
    }

    public void changeFeature() {
        try {
            if (isElementPresentByText("Заказать услугу")) {
                driver.findElement(By.linkText("Заказать услугу")).click();

                for (int i = 0; i < 5; i++) {
                    if (isElementPresentByXpath(".//*[@value='Продолжить']")) {
                        driver.findElement(By.xpath(".//*[@value='Продолжить']")).click();
                        LOG.info("Продолжить");
                        continue;
                    } else if (isElementPresentByXpath(".//*[@value='Подать заявку']")) {
                        driver.findElement(By.xpath(".//*[@value='Подать заявку']")).click();
                        continue;
                    } else if (isElementPresentByXpath(Locators.greenMessage)) {
                        LOG.info("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                        takeScreenshot("Success message: " + driver.findElement(By.xpath(Locators.greenMessage)).getText());
                        break;
                    } else if (isElementPresentByXpath(Locators.errorMessage)) {
                        LOG.info("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                        takeScreenshot("ErrorMessage: " + driver.findElement(By.xpath(Locators.errorMessage)).getText());
                        break;
                    } else {
                        LOG.info("Nothing");
                        break;
                    }
                }
            } else {
                LOG.info("No Active Feature");
            }
        } catch (Exception e) {
            LOG.info("ERROR on changeFeature(): " + e);
        }
    }
    public void verifyClickableElements(String s){};
}
