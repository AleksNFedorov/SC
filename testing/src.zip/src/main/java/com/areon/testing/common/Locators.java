package com.areon.testing.common;

import java.io.IOException;
import java.util.Locale;
import java.util.Properties;

public class Locators {

    public static final String TIME_FORMAT = "MM_dd_h_mm_ss";

    public static final Locale LOCALE_UA = new Locale("ukrainian","ua","UA");
    public static final Locale LOCALE_RU = new Locale("russian","ru","RU");
    public static final Locale LOCALE_US = Locale.US;
    public static final String DJUICE_PAGE_CORE_ELEMENTS = "linksOverviewPage";


    private static final Properties applicationProperties = new Properties();


    public enum BrowserWindowState {
        Closed,
        Open
    }

    public enum TestDataContainer {
        TestContent,
        TestContentDescription
    }


    public enum ResultType {
        Success,
        Fail;
    }

    public enum Segment {
        DJUICE,
        FTTB,
    }

    public enum Browser {
        Chrome,
        InternetExplorer,
        FireFox,
        Opera
    }

    public enum ReportType {
        XML,
        CSV
    }


    static {
        try {
            applicationProperties.load(Locators.class.getResourceAsStream("/app.properties"));
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }


    public final static String loginFormXpath = ".//*[@id='login']";
    public final static String passwordFormName = "password";
    public final static String submitButtonName = "Submit";
    public final static String GO_TO_BASE_URL = "base.mk.url";
    public final static String GO_TO_BASE_URL_DJUICE = "base.djuice.url";



    public final static String pageXpath = "//html";

    public final static String selectReportPeriod = ".//*[@name='selectedDate']";
    public final static String generateReportButton = ".//*[@value='Перейти']";
//    public final static String downloadOnFileLink = "сохранить в файл";
    public final static String formSelectDownloadFile = ".//*[@name='selectedDownloadType']";
//    public final static String buttonDownload = ".//*[@value='Загрузить']";
    public final static String printLink = "версия для печати";

    public final static String receiveButtonRu = ".//*[@value='Получить']";
    public final static String receiveButtonUa = ".//*[@value='Отримати']";
    public final static String confirmButtonRu = ".//*[@value='Подтверждаю']";
    public final static String confirmButtonUa =".//*[@value='Підтверджую']";

    public final static String greenMessage = ".//*[@class='greenSuccess']";
    public final static String errorMessage = ".//*[@id='errorsTable']";

    public final static String GENERAL_EDIT_BUTTON = "general.edit.button";
    public final static String GENERAL_SAVE_BUTTON = "general.save.button";

    public final static String submitButton = ".//*[@id='submit']";

    public static final String DJUICE_LOGIN = "djuice.login";
    public static final String DJUICE_PASSWORD = "djuice.password";
    public static final String FTTB_LOGIN = "fttb.login";
    public static final String FTTB_PASSWORD = "fttb.password";

    public static final String REPORT_FOLDER = "report.folder";

    public static final String LOCALE_XPATH_DJUICE_KEY = "localeSwitchXpathDJUICE";
    public static final String LOCALE_XPATH_MK_KEY = "localeSwitchXpathMK";

    public static final String REPORT_SAVE_TO_FILE_LINK="report.save.to.file.link";
    public static final String REPORT_DOWNLOAD_LINK="report.download.link";


    public final static String TITLE_OVERVIEW_DJUICE = "overview.djuice";
    public final static String TITLE_COST_DJUICE = "costsummary.djuice";
    public final static String TITLE_DETAIL_USAGE_DJUICE = "detailusage.djuice";
    public final static String TITLE_UNBILL_USAGE_DJUICE = "unbilledusage.djuice";
    public final static String TITLE_WIRELESS_NUMBER_DJUICE = "wirelessnumber.djuice";
    public final static String TITLE_REPORTS_DJUICE = "reports.djuice";
    public final static String TITLE_PERSONAL_PROFILE_DJUICE = "personalprofile.djuice";
    public final static String TITLE_NOTIFICATIONS_DJUICE = "notifications.djuice";
    public final static String TITLE_PAYMENT_ACTIVITY_DJUICE = "payment.djuice";
    public final static String TITLE_FEATURE_OVERVIEW_DJUICE = "featureoverview.djuice";
    public final static String TITLE_ARCHIVE_ORDERS_DJUICE = "archiveorders.djuice";
    public final static String TITLE_COMMUNICATION_DJUICE = "communication.djuice";
    public final static String TITLE_APPLICATION_FORM_DJUICE = "applicationform.djuice";
    public final static String TITLE_MONEY_TRANSFER_DJUICE = "moneytransfer.djuice";
    public final static String TITLE_MONEY_PROVIDERS_DJUICE = "moneyproviders.djuice";
    public final static String TITLE_SEND_QUESTION_DJUICE = "senfquestion.djuice";
    public final static String TITLE_FAQ_DJUICE = "faq.djuice";
    public final static String TITLE_USER_MANUAL_DJUICE = "usermanual.djuice";
    public final static String TITLE_TERMS_CONDITIONS_DJUICE = "termsconditions.djuice";
    public final static String TITLE_SITEMAP_DJUICE = "sitemap.djuice";
    
    public final static String VERIFY_TIMEOUT_PAGE = "timeoutpage.djuice";
    public final static  String TITLE_OVERVIEW_DJUICE_UA = "Мій DJUICE - Огляд";
    public final static  String TITLE_OVERVIEW_DJUICE_RU = "Мой DJUICE - Обзор";
    public final static  String TITLE_COST_DJUICE_UA = "Мій DJUICE - Сумарно";
    public final static  String TITLE_COST_DJUICE_RU = "Мой DJUICE - Cуммарно";
    public final static  String TITLE_DETAIL_USAGE_RU = "Мой DJUICE - Детализация вызовов";
    public final static  String TITLE_DETAIL_USAGE_UA = "Мій DJUICE - Деталізація викликів";
    public final static  String TITLE_UNBILL_USAGE_RU = "Мой DJUICE - Вызовы за текущий месяц";
    public final static  String TITLE_UNBILL_USAGE_UA = "Мій DJUICE - Виклики за поточний місяць";

    public static final String DJUICE_COST_SUMMARY_PAGE_ELEMENTS = "djuice.cost.summary.page.elements";

    //------------ data for checking UI for fttb segment ------------
    //data for check title pages
    public static final String TITLE_OVERVIEW_FTTB = "overview.fttb";
    public static final String TITLE_WIRELESS_NUMBER_FTTB = "wirelessnumber.fttb";
    public static final String TITLE_UNBILLED_USAGE_FTTB = "unbilledusage.fttb";
    public static final String TITLE_REPORTS_FTTB = "reportsbonus.fttb";
    public static final String TITLE_PROFILE_SHOW_FTTB = "profileshow.fttb";
    public static final String TITLE_PROFILE_NOTIFICATION_FTTB = "profilenotification.fttb";
    public static final String TITLE_PROFILE_ADDRESS_BOOK_FTTB = "addressbook.fttb";
    public static final String TITLE_PAYMENT_FTTB = "payment.fttb";
    public static final String TITLE_TSM_OVERVIEW_FTTB = "tsmovwerview.fttb";
    public static final String TITLE_TSM_ARCHIVE_ORDERS_FTTB = "archiveorders.fttb";
    public static final String TITLE_PROVIDERS_FTTB = "providers.fttb";
    public static final String TITLE_HELP_INSIDE_FTTB = "helpinside.fttb";
    public static final String TITLE_USER_MANUAL_FTTB = "usermanual.fttb";
    public static final String TITLE_FEEDBACK_FTTB = "feedback.fttb";
    public static final String TITLE_SITEMAP_FTTB = "sitemap.fttb";
    public static final String DJUICE_DETAIL_USAGE_PAGE_ELEMENTS = "djuice.detail.usage.page.elements";

    //data for check general links on pages
    public static final String FTTB_PAGE_CORE_ELEMENTS = "linksoverviewpage.fttb";
    public static final String FTTB_PAGE_AGREEMENT_ELEMENTS = "linkswirelessnumber.fttb";
    public static final String FTTB_PAGE_UNBILLED_USAGE_ELEMENTS = "linksunbilledussage.fttb";
    public static final String FTTB_PAGE_PROFILE_SHOW_ELEMENTS = "linksprofileshow.fttb";
    public static final String FTTB_PAGE_TSM_OVERVIEW_ELEMENTS = "linkstsmoverview.fttb";
    public static final String FTTB_PAGE_HELP_INSIDE_ELEMENTS = "linkshelpinside.fttb";


    //data for check UI text on pages
    public static final String FTTB_OVERVIEW_PAGE_ELEMENTS = "fttb.overview.page.elements";
    public static final String FTTB_PAGE_AGREEMENT_TEXT_ELEMENTS = "fttb.wirelessnumber.page.elements";
    public static final String FTTB_PAGE_ACCOUNT_DETAILED_TEXT_ELEMENTS = "fttb.accountdetailcharge.page.elements";
    public static final String FTTB_PAGE_REPORTS_BONUS_TEXT_ELEMENTS = "fttb.reports.bonus.elements";
    public static final String FTTB_PAGE_PROFILE_SHOW_TEXT_ELEMENTS = "fttb.profile.show.elements";
    public static final String FTTB_PAGE_PROFILE_NOTIFICATION_ELEMENTS = "fttb.profile.notifications.elements";
    public static final String FTTB_PAGE_PROFILE_ADDRESS_BOOK_ELEMENTS = "fttb.profile.address.book.elements";
    public static final String FTTB_PAGE_PAYMENT_ELEMENTS = "fttb.payment.elements";
    public static final String FTTB_PAGE_TSM_OVERVIEW_TEXT_ELEMENTS = "fttb.tsm.overview.elements";
    public static final String FTTB_PAGE_ARCHIVE_ORDERS_TEXT_ELEMENTS = "fttb.archive.orders.elements";
    public static final String FTTB_PAGE_PROVIDERS_ELEMENTS = "fttb.providers.elements";
    public static final String FTTB_PAGE_HELP_INSIDE_TEXT_ELEMENTS = "fttb.help.inside.elements";
    public static final String FTTB_PAGE_FEEDBACK_TEXT_ELEMENTS = "fttb.feedback.elements";
    public static final String FTTB_PAGE_SITEMAP_TEXT_ELEMENTS = "fttb.sitemap.elements";
    public static final String FTTB_PAGE_NO_DATA = "fttb.nodata.elements";

    //data for check button on pages
    public static final String FTTB_REPORT_SAVE_TO_FILE_LINK = "fttb.wirelessnumber.summary.page.save.to.file";
    public static final String FTTB_REPORT_DOWNLOAD_LINK = "fttb.wirelessnumber.summary.page.download.link";

    public static final String DJUICE_UNBILL_USAGE_PAGE_ELEMENTS = "djuice.unbill.usage.page.elements";

    public static final String DJUICE_WIRELESS_NUMBER_PAGE_ELEMENTS = "djuice.wireless.number.page.elements";


    public static final String DJUICE_REPORTS_PAGE_ELEMENTS = "djuice.reports.page.elements";

    public static final String DJUICE_PERSONAL_PROFILE_PAGE_ELEMENTS= "djuice.personal.profile.page.elements";

    public static final String DJUICE_PAYMENT_PAGE_ELEMENTS = "djuice.payment.page.elements";
    public static final String DJUICE_NOTIFICATIONS_PAGE_ELEMENTS = "djuice.notifications.page.elements";

    public static final String DJUICE_FEATURE_OVERVIEW_PAGE_ELEMENTS = "djuice.feature.overview.page.elements";

    public static final String LINKS_COST_PAGE = "djuice.links.cost.page";
    public static final String LINKS_PERSONAL_PROFILE = "djuice.links.personal.profile";
    public static final String LINKS_PAYMENTS = "djuice.links.payments";
    public static final String LINKS_FEATURE_OVERVIEW = "djuice.links.feature.overview";
    public static final String LINKS_COMMUNICATION = "djuice.links.communication";
    public static final String LINKS_APPLICATION_FORM = "djuice.links.application.form";
    public static final String LINKS_MONEY_TRANSFER = "djuice.links.money.transfer";
    public static final String LINKS_SEND_QUESTION = "djuice.links.send.question";
    public static final String LINKS_FAQ = "djuice.links.faq";
    public static final String LINKS_SITE_MAP = "djuice.links.site.map";

    public static String getApplicationProperty(String propertyKey) {
        return applicationProperties.getProperty(propertyKey);
    }

}
