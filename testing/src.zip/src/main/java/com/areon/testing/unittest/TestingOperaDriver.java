package com.areon.testing.unittest;

import com.opera.core.systems.OperaDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: Iaremenkoand
 * Date: 20.11.13
 * Time: 15:16
 * To change this template use File | Settings | File Templates.
 */
@Test
public class TestingOperaDriver {

    WebDriver driver = new OperaDriver();
    //driver.navigate().to("http://opera.com/");

    public void TC_2000() {

        final String opURL = "http://www.google.com";
        driver.get(opURL);
        WebElement opSerch = driver.findElement(By.xpath(".//*[@id='login']"));
        opSerch.sendKeys("+380975310412");
        WebElement opPassw = driver.findElement(By.xpath(".//*[@id='password']"));
        opPassw.sendKeys("SelfCare");
        WebElement opButt = driver.findElement(By.xpath(".//*[@id='login_submit']"));
        opButt.click();

        driver.close();

    }
}
