package com.areon.testing.unittest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.io.File;

/**
 * Created with IntelliJ IDEA.
 * User: Iaremenkoand
 * Date: 20.11.13
 * Time: 15:14
 * To change this template use File | Settings | File Templates.
 */
@Test
public class TestingInternetExplorerDriver {

    private static org.slf4j.Logger LOG = LoggerFactory.getLogger(TestingInternetExplorerDriver.class);

    public void runStartingPage() {
        File file = new File("D:/Qaautomated/Libs/IEDriverServer.exe");
        System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
        WebDriver driver = new InternetExplorerDriver();

        final String sUrl = "http://www.google.com";
        driver.get(sUrl);
        WebElement oSearchInputElemLog = driver.findElement(By.xpath(".//*[@id='login']"));
        oSearchInputElemLog.clear();
        oSearchInputElemLog.sendKeys("+380975310412");
        WebElement oSearchInputElempass = driver.findElement(By.xpath(".//*[@id='password']"));
        oSearchInputElempass.sendKeys("SelfCare");
        WebElement oSearchPushBtn = driver.findElement(By.xpath(".//*[@id='login_submit']"));
        oSearchPushBtn.click();

        driver.close();
    }
}
